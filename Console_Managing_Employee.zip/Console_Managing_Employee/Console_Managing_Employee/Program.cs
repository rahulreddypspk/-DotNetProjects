﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Managing_Employee
{
    class Program
    {
        static void Main(string[] args)
        {
            Company c= new Company("rahul", "HYD");
            bool flag= true;
            while(flag)
            {
                Console.WriteLine("enter ur option 1-Add,2-Search,3-Remove,4-Show,5-Leave");
                int opt = Convert.ToInt32(Console.ReadLine());

                switch(opt)
                {
                    case 1:
                        Console.WriteLine("enter Employee name:");
                        string Name = Console.ReadLine();
                        Console.WriteLine("enter Employee city:");
                        string City = Console.ReadLine();
                        Employee e = new Employee(Name, City);
                        c.AddEmployee(e);
                        Console.WriteLine("Employee Added :" + e.PEmployeeID);
                        break;
                    case 2:
                        Console.WriteLine("Enter Employee ID:");
                        int ID = Convert.ToInt32(Console.ReadLine());
                        Employee obj = c.Search(ID);
                        if (obj != null)
                        {
                            Console.WriteLine(obj.PEmployeeID + " " + obj.PEmployeeName);
                        }
                        break;
                    case 3:
                        Console.WriteLine("Enter Employee ID:");
                        int EID = Convert.ToInt32(Console.ReadLine());
                        bool status = c.Remove(EID);
                        if (status)
                        {
                            Console.WriteLine("Employee Removed");
                        }
                        else
                        {
                            Console.WriteLine("Employee not found");
                        }
                        break;

                    case 4:
                        c.Show();
                        break;
                    case 5:
                        Console.WriteLine("enter Employee id:");
                        int EmployeeID = Convert.ToInt32(Console.ReadLine());
                        Employee sobj = c.Search(EmployeeID);
                        Console.WriteLine("enter Reason:");
                        string Reason = Console.ReadLine();
                        sobj.TakeLeave(Reason);

                        break;
                }
            }

        }
    }
}
