﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Managing_Employee
{
    class Company
    {
        public void onLeave(int ID, string Reason)
        {
            Console.WriteLine("Company class : Employee on leave:" + ID + " ," + Reason);
        }



        private string Address;
            private string CompanyName;
             
            public Company(string CompanyName, string Address)
        {
            this.Address = Address;
            this.CompanyName = CompanyName;
        }

        private List<Employee> EmployeeDetails = new List<Employee>();

        public void AddEmployee(Employee emp)
        {
                 
            emp.evtleave += new Employee.delleave(this.onLeave);


            EmployeeDetails.Add(emp);
        }

        public Employee Search(int ID)
        {
            foreach(Employee emp in EmployeeDetails)
            {
                if(emp.PEmployeeID==ID)
                {
                    return emp;

                }
            }
            return null;
          }

        public bool Remove(int ID)
        {
            foreach (Employee emp in EmployeeDetails)
            {
                if (emp.PEmployeeID == ID)
                {
                    EmployeeDetails.Remove(emp);
                    return true;
                }
            }
            return false;
        }
        public void Show()
        {
            foreach(Employee emp in EmployeeDetails)
            {
                Console.WriteLine(emp.PEmployeeID + " " + emp.PEmployeeName + " " + emp.PEmployeeCity);
            }
        }



    }
}
