﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OPP_Interface
{
    class Program
    {
        static void Main(string[] args)
        {
            ProductA obj1 = new ProductA(1001, "DotNet");
            ProductB obj2 = new ProductB(2001, "ONePlus");

            Transport t = new Transport();

            t.send(obj1);
            t.send(obj2);

            Console.ReadLine();

        }
    }
}
