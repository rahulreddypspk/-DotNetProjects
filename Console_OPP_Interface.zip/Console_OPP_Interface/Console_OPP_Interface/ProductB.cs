﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OPP_Interface
{
    class ProductB : IProductTransport
    {
        private int PID;
        private string PName;

        public ProductB(int PID,string PName)
        {
            this.PID = PID;
            this.PName = PName;

        }

        public string GetAddress()
        {
            return "plot no:30,goa";
        }

        public int GetPrice()
        {
            return 20000;
        }

        public void start()
        { }

        public void stop()
        { }
    }
}
