﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Win_Threads
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_newthread_Click(object sender, EventArgs e)
        {
            ThreadStart d = new ThreadStart(this.call);
            Thread th = new Thread(d);
            th.IsBackground = true;
            th.Start();// create new thread
            

           /* Thread th2 = new Thread(this.call);
            th2.IsBackground = true;
            th2.Start();

            Thread th3 = new Thread(() =>
              {
                  MessageBox.Show("new task 3 using lamda update1");
              });
            th3.IsBackground = true;
            th3.Start();*/
            MessageBox.Show("Main thread Task");
            th.Join();

            MessageBox.Show("Main thread Task2");
        }

        public void call()
        {
            MessageBox.Show("new thread task started");
            Thread.Sleep(10000);
            MessageBox.Show("new thread task completed");
        }
    }
}
