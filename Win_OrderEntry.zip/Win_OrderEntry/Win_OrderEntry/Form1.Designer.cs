﻿namespace Win_OrderEntry
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_orderid = new System.Windows.Forms.TextBox();
            this.lbn_orderid = new System.Windows.Forms.Label();
            this.lbl_customername = new System.Windows.Forms.Label();
            this.txt_customername = new System.Windows.Forms.TextBox();
            this.lbl_itemid = new System.Windows.Forms.Label();
            this.txt_itemid = new System.Windows.Forms.TextBox();
            this.lbl_itemquantity = new System.Windows.Forms.Label();
            this.txt_itemquantity = new System.Windows.Forms.TextBox();
            this.lbl_itemprice = new System.Windows.Forms.Label();
            this.txt_itemprice = new System.Windows.Forms.TextBox();
            this.lbl_deliveryaddress = new System.Windows.Forms.Label();
            this.txt_deliveryaddress = new System.Windows.Forms.TextBox();
            this.cmb_ordercity = new System.Windows.Forms.ComboBox();
            this.lbl_ordercity = new System.Windows.Forms.Label();
            this.lbl_paymentoption = new System.Windows.Forms.Label();
            this.rdb_cod = new System.Windows.Forms.RadioButton();
            this.rdb_netbanking = new System.Windows.Forms.RadioButton();
            this.rdb_debitcard = new System.Windows.Forms.RadioButton();
            this.btn_placeorder = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt_orderid
            // 
            this.txt_orderid.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_orderid.Location = new System.Drawing.Point(222, 45);
            this.txt_orderid.Name = "txt_orderid";
            this.txt_orderid.Size = new System.Drawing.Size(133, 26);
            this.txt_orderid.TabIndex = 0;
            // 
            // lbn_orderid
            // 
            this.lbn_orderid.AutoSize = true;
            this.lbn_orderid.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbn_orderid.Location = new System.Drawing.Point(97, 40);
            this.lbn_orderid.Name = "lbn_orderid";
            this.lbn_orderid.Size = new System.Drawing.Size(119, 31);
            this.lbn_orderid.TabIndex = 1;
            this.lbn_orderid.Text = "OrderID:";
            this.lbn_orderid.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbl_customername
            // 
            this.lbl_customername.AutoSize = true;
            this.lbl_customername.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customername.Location = new System.Drawing.Point(4, 106);
            this.lbl_customername.Name = "lbl_customername";
            this.lbl_customername.Size = new System.Drawing.Size(212, 31);
            this.lbl_customername.TabIndex = 2;
            this.lbl_customername.Text = "CustomerName:";
            // 
            // txt_customername
            // 
            this.txt_customername.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customername.Location = new System.Drawing.Point(222, 115);
            this.txt_customername.Name = "txt_customername";
            this.txt_customername.Size = new System.Drawing.Size(133, 26);
            this.txt_customername.TabIndex = 3;
            // 
            // lbl_itemid
            // 
            this.lbl_itemid.AutoSize = true;
            this.lbl_itemid.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_itemid.Location = new System.Drawing.Point(113, 161);
            this.lbl_itemid.Name = "lbl_itemid";
            this.lbl_itemid.Size = new System.Drawing.Size(103, 31);
            this.lbl_itemid.TabIndex = 4;
            this.lbl_itemid.Text = "ItemID:";
            // 
            // txt_itemid
            // 
            this.txt_itemid.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_itemid.Location = new System.Drawing.Point(222, 171);
            this.txt_itemid.Name = "txt_itemid";
            this.txt_itemid.Size = new System.Drawing.Size(133, 26);
            this.txt_itemid.TabIndex = 5;
            // 
            // lbl_itemquantity
            // 
            this.lbl_itemquantity.AutoSize = true;
            this.lbl_itemquantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_itemquantity.Location = new System.Drawing.Point(39, 209);
            this.lbl_itemquantity.Name = "lbl_itemquantity";
            this.lbl_itemquantity.Size = new System.Drawing.Size(177, 31);
            this.lbl_itemquantity.TabIndex = 6;
            this.lbl_itemquantity.Text = "ItemQuantity:";
            // 
            // txt_itemquantity
            // 
            this.txt_itemquantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_itemquantity.Location = new System.Drawing.Point(222, 216);
            this.txt_itemquantity.Name = "txt_itemquantity";
            this.txt_itemquantity.Size = new System.Drawing.Size(133, 26);
            this.txt_itemquantity.TabIndex = 7;
            // 
            // lbl_itemprice
            // 
            this.lbl_itemprice.AutoSize = true;
            this.lbl_itemprice.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_itemprice.Location = new System.Drawing.Point(79, 261);
            this.lbl_itemprice.Name = "lbl_itemprice";
            this.lbl_itemprice.Size = new System.Drawing.Size(137, 31);
            this.lbl_itemprice.TabIndex = 8;
            this.lbl_itemprice.Text = "ItemPrice:";
            // 
            // txt_itemprice
            // 
            this.txt_itemprice.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_itemprice.Location = new System.Drawing.Point(222, 266);
            this.txt_itemprice.Name = "txt_itemprice";
            this.txt_itemprice.Size = new System.Drawing.Size(133, 26);
            this.txt_itemprice.TabIndex = 9;
            // 
            // lbl_deliveryaddress
            // 
            this.lbl_deliveryaddress.AutoSize = true;
            this.lbl_deliveryaddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_deliveryaddress.Location = new System.Drawing.Point(-5, 303);
            this.lbl_deliveryaddress.Name = "lbl_deliveryaddress";
            this.lbl_deliveryaddress.Size = new System.Drawing.Size(221, 31);
            this.lbl_deliveryaddress.TabIndex = 10;
            this.lbl_deliveryaddress.Text = "DeliveryAddress:";
            // 
            // txt_deliveryaddress
            // 
            this.txt_deliveryaddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_deliveryaddress.Location = new System.Drawing.Point(222, 310);
            this.txt_deliveryaddress.Name = "txt_deliveryaddress";
            this.txt_deliveryaddress.Size = new System.Drawing.Size(133, 26);
            this.txt_deliveryaddress.TabIndex = 11;
            // 
            // cmb_ordercity
            // 
            this.cmb_ordercity.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_ordercity.FormattingEnabled = true;
            this.cmb_ordercity.Location = new System.Drawing.Point(222, 358);
            this.cmb_ordercity.Name = "cmb_ordercity";
            this.cmb_ordercity.Size = new System.Drawing.Size(133, 28);
            this.cmb_ordercity.TabIndex = 12;
            this.cmb_ordercity.SelectedIndexChanged += new System.EventHandler(this.cmb_ordercity_SelectedIndexChanged);
            // 
            // lbl_ordercity
            // 
            this.lbl_ordercity.AutoSize = true;
            this.lbl_ordercity.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ordercity.Location = new System.Drawing.Point(68, 355);
            this.lbl_ordercity.Name = "lbl_ordercity";
            this.lbl_ordercity.Size = new System.Drawing.Size(139, 31);
            this.lbl_ordercity.TabIndex = 13;
            this.lbl_ordercity.Text = "OrderCity:";
            // 
            // lbl_paymentoption
            // 
            this.lbl_paymentoption.AutoSize = true;
            this.lbl_paymentoption.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_paymentoption.Location = new System.Drawing.Point(439, 45);
            this.lbl_paymentoption.Name = "lbl_paymentoption";
            this.lbl_paymentoption.Size = new System.Drawing.Size(209, 31);
            this.lbl_paymentoption.TabIndex = 14;
            this.lbl_paymentoption.Text = "PaymentOption:";
            this.lbl_paymentoption.Click += new System.EventHandler(this.lbl_paymentoption_Click);
            // 
            // rdb_cod
            // 
            this.rdb_cod.AutoSize = true;
            this.rdb_cod.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdb_cod.Location = new System.Drawing.Point(435, 127);
            this.rdb_cod.Name = "rdb_cod";
            this.rdb_cod.Size = new System.Drawing.Size(78, 29);
            this.rdb_cod.TabIndex = 15;
            this.rdb_cod.TabStop = true;
            this.rdb_cod.Text = "COD";
            this.rdb_cod.UseVisualStyleBackColor = true;
            this.rdb_cod.CheckedChanged += new System.EventHandler(this.rdb_cod_CheckedChanged);
            // 
            // rdb_netbanking
            // 
            this.rdb_netbanking.AutoSize = true;
            this.rdb_netbanking.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdb_netbanking.Location = new System.Drawing.Point(533, 127);
            this.rdb_netbanking.Name = "rdb_netbanking";
            this.rdb_netbanking.Size = new System.Drawing.Size(134, 29);
            this.rdb_netbanking.TabIndex = 16;
            this.rdb_netbanking.TabStop = true;
            this.rdb_netbanking.Text = "NetBanking";
            this.rdb_netbanking.UseVisualStyleBackColor = true;
            // 
            // rdb_debitcard
            // 
            this.rdb_debitcard.AutoSize = true;
            this.rdb_debitcard.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdb_debitcard.Location = new System.Drawing.Point(708, 127);
            this.rdb_debitcard.Name = "rdb_debitcard";
            this.rdb_debitcard.Size = new System.Drawing.Size(121, 29);
            this.rdb_debitcard.TabIndex = 17;
            this.rdb_debitcard.TabStop = true;
            this.rdb_debitcard.Text = "DebitCard";
            this.rdb_debitcard.UseVisualStyleBackColor = true;
            // 
            // btn_placeorder
            // 
            this.btn_placeorder.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_placeorder.Location = new System.Drawing.Point(469, 290);
            this.btn_placeorder.Name = "btn_placeorder";
            this.btn_placeorder.Size = new System.Drawing.Size(158, 44);
            this.btn_placeorder.TabIndex = 18;
            this.btn_placeorder.Text = "PlaceOrder";
            this.btn_placeorder.UseVisualStyleBackColor = true;
            this.btn_placeorder.Click += new System.EventHandler(this.btn_placeorder_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(918, 429);
            this.Controls.Add(this.btn_placeorder);
            this.Controls.Add(this.rdb_debitcard);
            this.Controls.Add(this.rdb_netbanking);
            this.Controls.Add(this.rdb_cod);
            this.Controls.Add(this.lbl_paymentoption);
            this.Controls.Add(this.lbl_ordercity);
            this.Controls.Add(this.cmb_ordercity);
            this.Controls.Add(this.txt_deliveryaddress);
            this.Controls.Add(this.lbl_deliveryaddress);
            this.Controls.Add(this.txt_itemprice);
            this.Controls.Add(this.lbl_itemprice);
            this.Controls.Add(this.txt_itemquantity);
            this.Controls.Add(this.lbl_itemquantity);
            this.Controls.Add(this.txt_itemid);
            this.Controls.Add(this.lbl_itemid);
            this.Controls.Add(this.txt_customername);
            this.Controls.Add(this.lbl_customername);
            this.Controls.Add(this.lbn_orderid);
            this.Controls.Add(this.txt_orderid);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_orderid;
        private System.Windows.Forms.Label lbn_orderid;
        private System.Windows.Forms.Label lbl_customername;
        private System.Windows.Forms.TextBox txt_customername;
        private System.Windows.Forms.Label lbl_itemid;
        private System.Windows.Forms.TextBox txt_itemid;
        private System.Windows.Forms.Label lbl_itemquantity;
        private System.Windows.Forms.TextBox txt_itemquantity;
        private System.Windows.Forms.Label lbl_itemprice;
        private System.Windows.Forms.TextBox txt_itemprice;
        private System.Windows.Forms.Label lbl_deliveryaddress;
        private System.Windows.Forms.TextBox txt_deliveryaddress;
        private System.Windows.Forms.ComboBox cmb_ordercity;
        private System.Windows.Forms.Label lbl_ordercity;
        private System.Windows.Forms.Label lbl_paymentoption;
        private System.Windows.Forms.RadioButton rdb_cod;
        private System.Windows.Forms.RadioButton rdb_netbanking;
        private System.Windows.Forms.RadioButton rdb_debitcard;
        private System.Windows.Forms.Button btn_placeorder;
    }
}

