﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_OrderEntry
{
    class OrderEntry
    {
        private int OrderID;
            private string CustomerName;
        private int ItemID;
        private int ItemQuantity;
        private int ItemPrice;
        private string DeliveryAddress;
        private string OrderCity;
       


        public OrderEntry(int OrderID,string CustomerName,int ItemID,int ItemQuantity,int ItemPrice
            ,string DeliveryAddress,string OrderCity )
        {
            this.OrderID = OrderID;
            this.CustomerName = CustomerName;
            this.ItemID = ItemID;
            this.ItemQuantity = ItemQuantity;
            this.ItemPrice = ItemPrice;
            this.DeliveryAddress = DeliveryAddress;
            this.OrderCity = OrderCity;

        }

        public int GetOrderValue()
        {
            return ItemPrice * ItemQuantity;

        }


        
    }
}
