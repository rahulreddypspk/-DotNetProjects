﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_OrderEntry
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            
            }
            
        

        private void Form1_Load(object sender, EventArgs e)
        {
            cmb_ordercity.Items.Add("HYD");
            cmb_ordercity.Items.Add("Bangalore");
            cmb_ordercity.Items.Add("Goa");
        }

        private void cmb_ordercity_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void btn_placeorder_Click(object sender, EventArgs e)
        {
            if (txt_orderid.Text == string.Empty)
            {
                MessageBox.Show("Enter Order ID:");
            }
            else if (txt_customername.Text == string.Empty)
            {
                MessageBox.Show("Enter Customer Name:");

            }
            else if (txt_itemid.Text == string.Empty)
            {
                MessageBox.Show("Enter Item ID:");
            }
            else if (txt_itemquantity.Text == string.Empty)
            {
                MessageBox.Show("Enter Item Quantity:");
            }
            else if (txt_itemprice.Text == string.Empty)
            {
                MessageBox.Show("Enter Item Price:");
            }
            else if (txt_deliveryaddress.Text == string.Empty)
            {
                MessageBox.Show("Enter Delivery Address:");

            }
            else if (rdb_cod.Checked == false && rdb_netbanking.Checked == false && rdb_debitcard.Checked == false)
            {
                MessageBox.Show("enter your option:");
            }
            else
            {
                string option = string.Empty;
                if (rdb_cod.Checked)
                {
                    option = "COD";
                }
                else if (rdb_netbanking.Checked)
                {
                    option = "NetBanking";
                }
                else

                {
                    option = "DebitCard";
                }
                    int orderID = Convert.ToInt32(txt_orderid.Text);
                    string customername = txt_customername.Text;
                    int itemID = Convert.ToInt32(txt_itemid.Text);
                    int itemquantity = Convert.ToInt32(txt_itemquantity.Text);
                    int itemprice = Convert.ToInt32(txt_itemprice.Text);
                    string deliveryaddress = txt_deliveryaddress.Text;
                    string ordercity = cmb_ordercity.Text;
                   

                    OrderEntry obj = new OrderEntry(orderID, customername, itemID, itemquantity, itemprice, deliveryaddress, ordercity);
              int amt=      obj.GetOrderValue();
                    MessageBox.Show( "Amount to be paid is:" +amt);

                }
            
        }
        private void lbl_paymentoption_Click(object sender, EventArgs e)
        {

        }

        private void rdb_cod_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
