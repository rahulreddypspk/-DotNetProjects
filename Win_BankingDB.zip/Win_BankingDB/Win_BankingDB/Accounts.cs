﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_BankingDB
{
    class Accounts
    {
        public int AccountID { get; set; }
        public int CustomerID { get; set; }
        public int AccountBalnce { get; set; }
        public string AccountType { get; set; }
        public DateTime AccountOpeningDate { get; set; }

    }

}
