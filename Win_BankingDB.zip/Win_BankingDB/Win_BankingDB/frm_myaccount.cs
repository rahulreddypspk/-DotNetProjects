﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_BankingDB
{
    public partial class frm_myaccount : Form
    {
        public frm_myaccount()
        {
            InitializeComponent();
        }

        private void btn_show_Click(object sender, EventArgs e)
        {
            if(txt_customerid.Text==string.Empty)
            {
                MessageBox.Show("enter id");
            }
            else
            {
                BankingDAL dal = new BankingDAL();

                int id = Convert.ToInt32(txt_customerid.Text);
                List<Accounts> list = dal.myaccount(id);
                dg_details.DataSource = list;

            }

        }

        private void frm_myaccount_Load(object sender, EventArgs e)
        {
            txt_customerid.Text = Test.CustomerID.ToString();
        }

        private void txt_customerid_TextChanged(object sender, EventArgs e)
        {
            txt_customerid.Enabled = false;
        }
    }
}
