﻿namespace Win_BankingDB
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_customerid = new System.Windows.Forms.Label();
            this.lbl_customername = new System.Windows.Forms.Label();
            this.lbl_customeremail = new System.Windows.Forms.Label();
            this.lbl_customermobileno = new System.Windows.Forms.Label();
            this.txt_customerid = new System.Windows.Forms.TextBox();
            this.txt_customername = new System.Windows.Forms.TextBox();
            this.txt_customeremail = new System.Windows.Forms.TextBox();
            this.txt_customermobileno = new System.Windows.Forms.TextBox();
            this.lbl_customergender = new System.Windows.Forms.Label();
            this.rdb_male = new System.Windows.Forms.RadioButton();
            this.rdb_female = new System.Windows.Forms.RadioButton();
            this.lbl_customerpassword = new System.Windows.Forms.Label();
            this.txt_customerpassword = new System.Windows.Forms.TextBox();
            this.btn_new = new System.Windows.Forms.Button();
            this.lbl_loginid = new System.Windows.Forms.Label();
            this.lbl_password = new System.Windows.Forms.Label();
            this.txt_loginid = new System.Windows.Forms.TextBox();
            this.txt_password = new System.Windows.Forms.TextBox();
            this.btn_login = new System.Windows.Forms.Button();
            this.btn_reset = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_customerid
            // 
            this.lbl_customerid.AutoSize = true;
            this.lbl_customerid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customerid.Location = new System.Drawing.Point(99, 34);
            this.lbl_customerid.Name = "lbl_customerid";
            this.lbl_customerid.Size = new System.Drawing.Size(161, 29);
            this.lbl_customerid.TabIndex = 0;
            this.lbl_customerid.Text = "Customer ID:";
            // 
            // lbl_customername
            // 
            this.lbl_customername.AutoSize = true;
            this.lbl_customername.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customername.Location = new System.Drawing.Point(55, 91);
            this.lbl_customername.Name = "lbl_customername";
            this.lbl_customername.Size = new System.Drawing.Size(205, 29);
            this.lbl_customername.TabIndex = 1;
            this.lbl_customername.Text = "Customer Name:";
            // 
            // lbl_customeremail
            // 
            this.lbl_customeremail.AutoSize = true;
            this.lbl_customeremail.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customeremail.Location = new System.Drawing.Point(58, 147);
            this.lbl_customeremail.Name = "lbl_customeremail";
            this.lbl_customeremail.Size = new System.Drawing.Size(202, 29);
            this.lbl_customeremail.TabIndex = 2;
            this.lbl_customeremail.Text = "Customer Email:";
            // 
            // lbl_customermobileno
            // 
            this.lbl_customermobileno.AutoSize = true;
            this.lbl_customermobileno.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customermobileno.Location = new System.Drawing.Point(11, 215);
            this.lbl_customermobileno.Name = "lbl_customermobileno";
            this.lbl_customermobileno.Size = new System.Drawing.Size(249, 29);
            this.lbl_customermobileno.TabIndex = 3;
            this.lbl_customermobileno.Text = "Customer MobileNO:";
            // 
            // txt_customerid
            // 
            this.txt_customerid.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customerid.Location = new System.Drawing.Point(266, 37);
            this.txt_customerid.Name = "txt_customerid";
            this.txt_customerid.Size = new System.Drawing.Size(155, 26);
            this.txt_customerid.TabIndex = 4;
            // 
            // txt_customername
            // 
            this.txt_customername.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customername.Location = new System.Drawing.Point(266, 96);
            this.txt_customername.Name = "txt_customername";
            this.txt_customername.Size = new System.Drawing.Size(155, 26);
            this.txt_customername.TabIndex = 5;
            // 
            // txt_customeremail
            // 
            this.txt_customeremail.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customeremail.Location = new System.Drawing.Point(266, 152);
            this.txt_customeremail.Name = "txt_customeremail";
            this.txt_customeremail.Size = new System.Drawing.Size(155, 26);
            this.txt_customeremail.TabIndex = 6;
            // 
            // txt_customermobileno
            // 
            this.txt_customermobileno.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customermobileno.Location = new System.Drawing.Point(266, 218);
            this.txt_customermobileno.Name = "txt_customermobileno";
            this.txt_customermobileno.Size = new System.Drawing.Size(155, 26);
            this.txt_customermobileno.TabIndex = 7;
            // 
            // lbl_customergender
            // 
            this.lbl_customergender.AutoSize = true;
            this.lbl_customergender.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customergender.Location = new System.Drawing.Point(40, 278);
            this.lbl_customergender.Name = "lbl_customergender";
            this.lbl_customergender.Size = new System.Drawing.Size(220, 29);
            this.lbl_customergender.TabIndex = 8;
            this.lbl_customergender.Text = "Customer Gender:";
            // 
            // rdb_male
            // 
            this.rdb_male.AutoSize = true;
            this.rdb_male.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdb_male.Location = new System.Drawing.Point(266, 286);
            this.rdb_male.Name = "rdb_male";
            this.rdb_male.Size = new System.Drawing.Size(66, 21);
            this.rdb_male.TabIndex = 9;
            this.rdb_male.TabStop = true;
            this.rdb_male.Text = "MALE";
            this.rdb_male.UseVisualStyleBackColor = true;
            // 
            // rdb_female
            // 
            this.rdb_female.AutoSize = true;
            this.rdb_female.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdb_female.Location = new System.Drawing.Point(339, 285);
            this.rdb_female.Name = "rdb_female";
            this.rdb_female.Size = new System.Drawing.Size(75, 21);
            this.rdb_female.TabIndex = 10;
            this.rdb_female.TabStop = true;
            this.rdb_female.Text = "Female";
            this.rdb_female.UseVisualStyleBackColor = true;
            // 
            // lbl_customerpassword
            // 
            this.lbl_customerpassword.AutoSize = true;
            this.lbl_customerpassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customerpassword.Location = new System.Drawing.Point(12, 335);
            this.lbl_customerpassword.Name = "lbl_customerpassword";
            this.lbl_customerpassword.Size = new System.Drawing.Size(248, 29);
            this.lbl_customerpassword.TabIndex = 11;
            this.lbl_customerpassword.Text = "Customer Password:";
            // 
            // txt_customerpassword
            // 
            this.txt_customerpassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customerpassword.Location = new System.Drawing.Point(266, 342);
            this.txt_customerpassword.Name = "txt_customerpassword";
            this.txt_customerpassword.Size = new System.Drawing.Size(155, 26);
            this.txt_customerpassword.TabIndex = 12;
            // 
            // btn_new
            // 
            this.btn_new.Location = new System.Drawing.Point(89, 387);
            this.btn_new.Name = "btn_new";
            this.btn_new.Size = new System.Drawing.Size(114, 45);
            this.btn_new.TabIndex = 13;
            this.btn_new.Text = "NEW";
            this.btn_new.UseVisualStyleBackColor = true;
            this.btn_new.Click += new System.EventHandler(this.btn_new_Click);
            // 
            // lbl_loginid
            // 
            this.lbl_loginid.AutoSize = true;
            this.lbl_loginid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_loginid.Location = new System.Drawing.Point(489, 47);
            this.lbl_loginid.Name = "lbl_loginid";
            this.lbl_loginid.Size = new System.Drawing.Size(127, 29);
            this.lbl_loginid.TabIndex = 14;
            this.lbl_loginid.Text = "LOGIN ID:";
            // 
            // lbl_password
            // 
            this.lbl_password.AutoSize = true;
            this.lbl_password.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_password.Location = new System.Drawing.Point(456, 121);
            this.lbl_password.Name = "lbl_password";
            this.lbl_password.Size = new System.Drawing.Size(167, 29);
            this.lbl_password.TabIndex = 15;
            this.lbl_password.Text = "PASSWORD:";
            // 
            // txt_loginid
            // 
            this.txt_loginid.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_loginid.Location = new System.Drawing.Point(635, 47);
            this.txt_loginid.Name = "txt_loginid";
            this.txt_loginid.Size = new System.Drawing.Size(167, 26);
            this.txt_loginid.TabIndex = 16;
            // 
            // txt_password
            // 
            this.txt_password.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_password.Location = new System.Drawing.Point(635, 121);
            this.txt_password.Name = "txt_password";
            this.txt_password.Size = new System.Drawing.Size(167, 26);
            this.txt_password.TabIndex = 17;
            this.txt_password.TextChanged += new System.EventHandler(this.txt_password_TextChanged);
            // 
            // btn_login
            // 
            this.btn_login.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_login.Location = new System.Drawing.Point(587, 190);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(129, 54);
            this.btn_login.TabIndex = 18;
            this.btn_login.Text = "LOGIN";
            this.btn_login.UseVisualStyleBackColor = true;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // btn_reset
            // 
            this.btn_reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_reset.Location = new System.Drawing.Point(291, 387);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(97, 48);
            this.btn_reset.TabIndex = 19;
            this.btn_reset.Text = "RESET";
            this.btn_reset.UseVisualStyleBackColor = true;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Highlight;
            this.ClientSize = new System.Drawing.Size(929, 444);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.btn_login);
            this.Controls.Add(this.txt_password);
            this.Controls.Add(this.txt_loginid);
            this.Controls.Add(this.lbl_password);
            this.Controls.Add(this.lbl_loginid);
            this.Controls.Add(this.btn_new);
            this.Controls.Add(this.txt_customerpassword);
            this.Controls.Add(this.lbl_customerpassword);
            this.Controls.Add(this.rdb_female);
            this.Controls.Add(this.rdb_male);
            this.Controls.Add(this.lbl_customergender);
            this.Controls.Add(this.txt_customermobileno);
            this.Controls.Add(this.txt_customeremail);
            this.Controls.Add(this.txt_customername);
            this.Controls.Add(this.txt_customerid);
            this.Controls.Add(this.lbl_customermobileno);
            this.Controls.Add(this.lbl_customeremail);
            this.Controls.Add(this.lbl_customername);
            this.Controls.Add(this.lbl_customerid);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_customerid;
        private System.Windows.Forms.Label lbl_customername;
        private System.Windows.Forms.Label lbl_customeremail;
        private System.Windows.Forms.Label lbl_customermobileno;
        private System.Windows.Forms.TextBox txt_customerid;
        private System.Windows.Forms.TextBox txt_customername;
        private System.Windows.Forms.TextBox txt_customeremail;
        private System.Windows.Forms.TextBox txt_customermobileno;
        private System.Windows.Forms.Label lbl_customergender;
        private System.Windows.Forms.RadioButton rdb_male;
        private System.Windows.Forms.RadioButton rdb_female;
        private System.Windows.Forms.Label lbl_customerpassword;
        private System.Windows.Forms.TextBox txt_customerpassword;
        private System.Windows.Forms.Button btn_new;
        private System.Windows.Forms.Label lbl_loginid;
        private System.Windows.Forms.Label lbl_password;
        private System.Windows.Forms.TextBox txt_loginid;
        private System.Windows.Forms.TextBox txt_password;
        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.Button btn_reset;
    }
}

