﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_BankingDB
{
    public partial class frm_mytransaction : Form
    {
        public frm_mytransaction()
        {
            InitializeComponent();
        }

        private void btn_show_Click(object sender, EventArgs e)
        {
            if(cmb_accountid.Text==string.Empty)
            {
                MessageBox.Show("enter id");
            }
            else
            {
                int id = Convert.ToInt32(cmb_accountid.Text);
                BankingDAL dal = new BankingDAL();

                List<Transactions> list = dal.mytransaction(id);
                dg_details.DataSource = list;

  }
            
        }

        private void frm_mytransaction_Load(object sender, EventArgs e)
        {
            BankingDAL dal = new BankingDAL();
            List<int> list = dal.Accid(Test.CustomerID);
          foreach( var g in list)
            {
                cmb_accountid.Items.Add(g);
            }
        }
    }
}
