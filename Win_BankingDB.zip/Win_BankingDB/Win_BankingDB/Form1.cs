﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_BankingDB
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_new_Click(object sender, EventArgs e)
        {
            if (txt_customername.Text == string.Empty)
            {
                MessageBox.Show("enter name");

            }
            else if (txt_customeremail.Text == string.Empty)
            {
                MessageBox.Show("enter email");

            }
            else if (txt_customermobileno.Text == string.Empty)
            {
                MessageBox.Show("enter mobile number");
            }
            else if (rdb_male.Checked == false && rdb_female.Checked == false)
            {
                string gender = string.Empty;
                if (rdb_male.Checked)
                {
                    gender = "male";
                }
                else if (rdb_female.Checked)
                {
                    gender = "female";
                }
                MessageBox.Show(gender);

            } 
        
            else if (txt_customerpassword.Text == string.Empty)
            {
                MessageBox.Show("enter password");

            }
            else
            { 
             string name = txt_customername.Text;
                string email = txt_customeremail.Text;
                string mobileno = txt_customermobileno.Text;
                string gender;
                if (rdb_male.Checked == true)
                {
                    gender = "male";
                }
                else
                {
                    gender = "female";
                }
                    string password = txt_customerpassword.Text;

                    Customers obj = new Customers();
                    obj.CustomerName = name;
                    obj.CustomerEmail = email;
                    obj.CustomerMobileNO = mobileno;
                    obj.CustomerGender = gender;
                obj.CustomerPassword = password;

                    BankingDAL dal = new BankingDAL();
                    int id = dal.AddCustomer(obj);
                    MessageBox.Show("customer added " + id);

               
            }
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            if(txt_loginid.Text==string.Empty)
            {
                MessageBox.Show("enter loginid");
            }
            else if(txt_password.Text==string.Empty)
            {
                MessageBox.Show("enter password");
            }
            else
            {
                int id = Convert.ToInt32(txt_loginid.Text);
                string password = txt_password.Text;

                BankingDAL dal = new BankingDAL();
                bool status = dal.login(id, password);
                if(status)
                {
                    MessageBox.Show("Valid user");

                    Test.CustomerID = Convert.ToInt32(txt_loginid.Text);

                    frm_4type a = new frm_4type();
                    a.Show();
                }
                else
                {
                    MessageBox.Show("Invalid user");
                }

                
              
            }
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            txt_customerid.Text = string.Empty;
            txt_customername.Text= string.Empty;
            txt_customeremail.Text = string.Empty;
            txt_customermobileno.Text = string.Empty;
            rdb_female.Text = string.Empty;
            rdb_male.Text = string.Empty;
            txt_customerpassword.Text = string.Empty;


            
        }

        private void txt_password_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
