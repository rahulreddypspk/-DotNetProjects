﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;


namespace Win_BankingDB
{
    class BankingDAL
    {
        SqlConnection con = new SqlConnection
            (ConfigurationManager.ConnectionStrings["bank"].ConnectionString);

        public int AddCustomer(Customers cust)
        {
            SqlCommand add_cust = new SqlCommand("proc_add_cust", con);
            add_cust.Parameters.AddWithValue("@name", cust.CustomerName);
            add_cust.Parameters.AddWithValue("@email", cust.CustomerEmail);
            add_cust.Parameters.AddWithValue("@mobileno", cust.CustomerMobileNO);
            add_cust.Parameters.AddWithValue("@gender", cust.CustomerGender);
            add_cust.Parameters.AddWithValue("@password", cust.CustomerPassword);
            add_cust.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();

            retdata.Direction = ParameterDirection.ReturnValue;
            add_cust.Parameters.Add(retdata);

            con.Open();
            add_cust.ExecuteNonQuery();
            con.Close();
            int id = Convert.ToInt32(retdata.Value);
            return id;
        }

        public bool login(int id,string password)
        {

           SqlCommand cust_login = new SqlCommand("proc_login", con);
            cust_login.Parameters.AddWithValue("@id", id);
            cust_login.Parameters.AddWithValue("@password", password);
            cust_login.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;

            cust_login.Parameters.Add(retdata);

            con.Open();
            cust_login.ExecuteNonQuery();
            con.Close();

            int count = Convert.ToInt32(retdata.Value);
            if(count>0)
            {
                return true;
            }
            else
            {
                return false;
            }
           
        }

        public int newaccount(int id,string acctype,int accbalance)
        {
            SqlCommand new_acc= new SqlCommand("proc_new_acc", con);
            new_acc.Parameters.AddWithValue("@id", id);
            new_acc.Parameters.AddWithValue("@acctype", acctype);
            new_acc.Parameters.AddWithValue("@accbalance", accbalance);
            
            new_acc.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            new_acc.Parameters.Add(retdata);
            con.Open();
            new_acc.ExecuteNonQuery();
            con.Close();
            int ID = Convert.ToInt32(retdata.Value);
            return ID;
        }

        public List<Accounts> myaccount(int id)
        {
            SqlCommand my_acc = new SqlCommand("proc_my_account", con);
            my_acc.Parameters.AddWithValue("@id", id);
            my_acc.CommandType = CommandType.StoredProcedure;
            
            con.Open();
            
            SqlDataReader dr = my_acc.ExecuteReader();
            List<Accounts> acclist = new List<Accounts>();
            while(dr.Read())
            {
                Accounts ac = new Accounts();
                ac.AccountID = dr.GetInt32(0);
                ac.CustomerID = dr.GetInt32(1);
                ac.AccountBalnce = dr.GetInt32(2);
                ac.AccountType = dr.GetString(3);
                
                acclist.Add(ac);
                
               }
            con.Close();
            return acclist;
           

        }

        public List<Transactions> mytransaction(int id)
        {
            SqlCommand my_trans = new SqlCommand("proc_my_transaction", con);
            my_trans.Parameters.AddWithValue("@id", id);
            my_trans.CommandType = CommandType.StoredProcedure;
           con.Open();
            SqlDataReader dr = my_trans.ExecuteReader();
            List<Transactions> translist = new List<Transactions>();
            while (dr.Read())
            {
                Transactions t = new Transactions();
                t.TransactionID = dr.GetInt32(0);
                t.AccountID = dr.GetInt32(1);
                t.Amount = dr.GetInt32(2);
                t.TransactionType = dr.GetString(3);
                t.TransactionDate = dr.GetDateTime(4);
                translist.Add(t);
                
            }
            con.Close();
            return translist;

           }
      
        public int NewTransaction(int id,int amt,string transtype)
        {
            SqlCommand new_trans = new SqlCommand("proc_new_transaction", con);
            new_trans.Parameters.AddWithValue("@id", id);
            new_trans.Parameters.AddWithValue("@amount", amt);
            new_trans.Parameters.AddWithValue("@trantype", transtype);
            new_trans.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            new_trans.Parameters.Add(retdata);
            con.Open();
            new_trans.ExecuteNonQuery();
            con.Close();
            int ID = Convert.ToInt32(retdata.Value);
            return ID;
        }

        public List<int> Accid(int id)
        {
            SqlCommand acid = new SqlCommand("proc_acc_cuss", con);
            acid.Parameters.AddWithValue("@cid", id);
            acid.CommandType = CommandType.StoredProcedure;
            
            
            con.Open();
            SqlDataReader dr = acid.ExecuteReader();
            List<int> list_accid = new List<int>();
            while (dr.Read())
            {
                list_accid.Add(dr.GetInt32(0));
            }

            con.Close();
            return list_accid;

        }
           

        
    }
}
