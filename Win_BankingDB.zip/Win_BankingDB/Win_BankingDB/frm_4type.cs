﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_BankingDB
{
    public partial class frm_4type : Form
    {
        public frm_4type()
        {
            InitializeComponent();
        }

        private void btn_myaccount_Click(object sender, EventArgs e)
        {
           frm_myaccount a = new frm_myaccount();
            a.Show();
        }

        private void btn_newtransaction_Click(object sender, EventArgs e)
        {
            frm_maketransaction a= new frm_maketransaction();
            a.Show();
        }

        private void btn_newaccount_Click(object sender, EventArgs e)
        {
            frm_newaccount a = new frm_newaccount();
            a.Show();
        }

        private void btn_mytransaction_Click(object sender, EventArgs e)
        {
           frm_mytransaction a = new frm_mytransaction();
            a.Show();
        }
    }
}
