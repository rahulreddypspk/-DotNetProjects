﻿namespace Win_BankingDB
{
    partial class frm_4type
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_newaccount = new System.Windows.Forms.Button();
            this.btn_myaccount = new System.Windows.Forms.Button();
            this.btn_newtransaction = new System.Windows.Forms.Button();
            this.btn_mytransaction = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_newaccount
            // 
            this.btn_newaccount.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_newaccount.Location = new System.Drawing.Point(65, 56);
            this.btn_newaccount.Name = "btn_newaccount";
            this.btn_newaccount.Size = new System.Drawing.Size(219, 62);
            this.btn_newaccount.TabIndex = 0;
            this.btn_newaccount.Text = "NEW ACCOUNT";
            this.btn_newaccount.UseVisualStyleBackColor = true;
            this.btn_newaccount.Click += new System.EventHandler(this.btn_newaccount_Click);
            // 
            // btn_myaccount
            // 
            this.btn_myaccount.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_myaccount.Location = new System.Drawing.Point(399, 58);
            this.btn_myaccount.Name = "btn_myaccount";
            this.btn_myaccount.Size = new System.Drawing.Size(207, 60);
            this.btn_myaccount.TabIndex = 1;
            this.btn_myaccount.Text = "MY Account";
            this.btn_myaccount.UseVisualStyleBackColor = true;
            this.btn_myaccount.Click += new System.EventHandler(this.btn_myaccount_Click);
            // 
            // btn_newtransaction
            // 
            this.btn_newtransaction.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_newtransaction.Location = new System.Drawing.Point(65, 186);
            this.btn_newtransaction.Name = "btn_newtransaction";
            this.btn_newtransaction.Size = new System.Drawing.Size(219, 62);
            this.btn_newtransaction.TabIndex = 2;
            this.btn_newtransaction.Text = "New Transaction";
            this.btn_newtransaction.UseVisualStyleBackColor = true;
            this.btn_newtransaction.Click += new System.EventHandler(this.btn_newtransaction_Click);
            // 
            // btn_mytransaction
            // 
            this.btn_mytransaction.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_mytransaction.Location = new System.Drawing.Point(399, 190);
            this.btn_mytransaction.Name = "btn_mytransaction";
            this.btn_mytransaction.Size = new System.Drawing.Size(207, 58);
            this.btn_mytransaction.TabIndex = 3;
            this.btn_mytransaction.Text = "MY Transaction";
            this.btn_mytransaction.UseVisualStyleBackColor = true;
            this.btn_mytransaction.Click += new System.EventHandler(this.btn_mytransaction_Click);
            // 
            // frm_4type
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(764, 363);
            this.Controls.Add(this.btn_mytransaction);
            this.Controls.Add(this.btn_newtransaction);
            this.Controls.Add(this.btn_myaccount);
            this.Controls.Add(this.btn_newaccount);
            this.Name = "frm_4type";
            this.Text = "frm_4type";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_newaccount;
        private System.Windows.Forms.Button btn_myaccount;
        private System.Windows.Forms.Button btn_newtransaction;
        private System.Windows.Forms.Button btn_mytransaction;
    }
}