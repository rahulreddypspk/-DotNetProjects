﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_BankingDB
{
    public partial class frm_newaccount : Form
    {
        public frm_newaccount()
        {
            InitializeComponent();
        }

        private void btn_new_Click(object sender, EventArgs e)
        {
            if(txt_customerid.Text==string.Empty)
            {
                MessageBox.Show("enter customer id");
            }
            else if(txt_accounttype.Text==string.Empty)
            {
                MessageBox.Show("enter account type");
            }
            else if(txt_balance.Text==string.Empty)
            {
                MessageBox.Show("enter balance");
            }
            else
            {
                int id = Convert.ToInt32(txt_customerid.Text);
                string acctype = txt_accounttype.Text;
                int balance = Convert.ToInt32(txt_balance.Text);

                BankingDAL dal = new BankingDAL();
                int ID = dal.newaccount(id,acctype,balance);
                MessageBox.Show("Account added" + ID);
                
            }
        }

        private void txt_customerid_TextChanged(object sender, EventArgs e)
        {
            txt_customerid.Enabled = false;
        }

        private void frm_newaccount_Load(object sender, EventArgs e)
        {
            txt_customerid.Text = Test.CustomerID.ToString();

        }
    }
}
