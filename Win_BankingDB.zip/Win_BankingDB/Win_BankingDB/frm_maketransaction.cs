﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_BankingDB
{
    public partial class frm_maketransaction : Form
    {
        public frm_maketransaction()
        {
            InitializeComponent();
        }

        private void btn_maketransaction_Click(object sender, EventArgs e)
        {
            if(cmb_accountid.Text==string.Empty)
            {
                MessageBox.Show("enter id");
            }
            else if(txt_amount.Text==string.Empty)
            {
                MessageBox.Show("enter amount");
            }
            else if(txt_transactiontype.Text==string.Empty)
            {
                MessageBox.Show("enter type");

            }
            else
            {
                int id = Convert.ToInt32(cmb_accountid.Text);
                int amount = Convert.ToInt32(txt_amount.Text);
                string type = txt_transactiontype.Text;

                BankingDAL dal = new BankingDAL();
                int ID = dal.NewTransaction(id, amount, type);
                MessageBox.Show("transaction success" + ID);
            }
        }

        private void frm_maketransaction_Load(object sender, EventArgs e)
        {
            BankingDAL dal = new BankingDAL();
            List<int> list = dal.Accid(Test.CustomerID);
            foreach(var m in list)
            {
                cmb_accountid.Items.Add(m);
            }

        }

        private void txt_accountid_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
