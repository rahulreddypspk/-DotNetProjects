﻿namespace Win_BankingDB
{
    partial class frm_mytransaction
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_accountid = new System.Windows.Forms.Label();
            this.btn_show = new System.Windows.Forms.Button();
            this.dg_details = new System.Windows.Forms.DataGridView();
            this.cmb_accountid = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dg_details)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_accountid
            // 
            this.lbl_accountid.AutoSize = true;
            this.lbl_accountid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_accountid.Location = new System.Drawing.Point(39, 50);
            this.lbl_accountid.Name = "lbl_accountid";
            this.lbl_accountid.Size = new System.Drawing.Size(143, 29);
            this.lbl_accountid.TabIndex = 0;
            this.lbl_accountid.Text = "Account ID:";
            // 
            // btn_show
            // 
            this.btn_show.Location = new System.Drawing.Point(112, 125);
            this.btn_show.Name = "btn_show";
            this.btn_show.Size = new System.Drawing.Size(146, 49);
            this.btn_show.TabIndex = 2;
            this.btn_show.Text = "SHOW";
            this.btn_show.UseVisualStyleBackColor = true;
            this.btn_show.Click += new System.EventHandler(this.btn_show_Click);
            // 
            // dg_details
            // 
            this.dg_details.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_details.Location = new System.Drawing.Point(27, 192);
            this.dg_details.Name = "dg_details";
            this.dg_details.RowTemplate.Height = 24;
            this.dg_details.Size = new System.Drawing.Size(769, 220);
            this.dg_details.TabIndex = 3;
            // 
            // cmb_accountid
            // 
            this.cmb_accountid.FormattingEnabled = true;
            this.cmb_accountid.Location = new System.Drawing.Point(188, 55);
            this.cmb_accountid.Name = "cmb_accountid";
            this.cmb_accountid.Size = new System.Drawing.Size(176, 24);
            this.cmb_accountid.TabIndex = 4;
            // 
            // frm_mytransaction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(866, 442);
            this.Controls.Add(this.cmb_accountid);
            this.Controls.Add(this.dg_details);
            this.Controls.Add(this.btn_show);
            this.Controls.Add(this.lbl_accountid);
            this.Name = "frm_mytransaction";
            this.Text = "frm_mytransaction";
            this.Load += new System.EventHandler(this.frm_mytransaction_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dg_details)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_accountid;
        private System.Windows.Forms.Button btn_show;
        private System.Windows.Forms.DataGridView dg_details;
        private System.Windows.Forms.ComboBox cmb_accountid;
    }
}