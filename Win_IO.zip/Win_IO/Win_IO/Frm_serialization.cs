﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml.Serialization;

namespace Win_IO
{
    public partial class Frm_serialization : Form
    {
        public Frm_serialization()
        {
            InitializeComponent();
        }

        private void btn_serializabile_Click(object sender, EventArgs e)
        {
            Product p = new Product();
            p.ProductID = Convert.ToInt32(txt_productid.Text);
            p.ProductName = txt_productname.Text;
            p.ProductPrice = Convert.ToInt32(txt_productprice.Text);


            FileStream fs = new FileStream("c:/Test/.product.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            BinaryFormatter b = new BinaryFormatter();
            b.Serialize(fs, p);
            fs.Close();
            MessageBox.Show("Binary Serialization Done");
        }

        private void btn_deserilization_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("c:/Test/.product.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            BinaryFormatter b = new BinaryFormatter();
            Product p = b.Deserialize(fs) as Product;
            fs.Close();
            txt_productid.Text = p.ProductID.ToString();
            txt_productname.Text = p.ProductName;
            txt_productprice.Text = p.ProductPrice.ToString();
        }

        private void btn_xmlserialize_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("c:/Test/prod.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            Product p = new Product();
            p.ProductID = Convert.ToInt32(txt_productid.Text);
            p.ProductName = txt_productname.Text;
            p.ProductPrice = Convert.ToInt32(txt_productprice.Text);

            XmlSerializer xml = new XmlSerializer(typeof(Product));
            xml.Serialize(fs, p);
            fs.Close();
            MessageBox.Show("XML Serialization Done");
        }

        private void btn_xmldeserialize_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("c:/Test/prod.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            XmlSerializer xml = new XmlSerializer(typeof(Product));
            Product p = xml.Deserialize(fs) as Product;
            fs.Close();
            txt_productid.Text = p.ProductID.ToString();
            txt_productname.Text = p.ProductName;
            txt_productprice.Text = p.ProductPrice.ToString();
        }
    }
}
