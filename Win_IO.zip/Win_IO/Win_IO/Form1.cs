﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Win_IO
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_binarywriter_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("c:/Test/a.txt", FileMode.OpenOrCreate,FileAccess.ReadWrite);
            BinaryWriter bw = new BinaryWriter(fs);
            int x = 100;
            bw.Write(x);
            bw.Flush();
            fs.Close();
            MessageBox.Show("File created");
        }

        private void btn_binaryreader_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("c:/Test/a.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            BinaryReader br = new BinaryReader(fs);
            int x = br.ReadInt32();
            fs.Close();
            MessageBox.Show(x.ToString());

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_streamwriter_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("c:/Test/b.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            StreamWriter sw = new StreamWriter(fs);
            string str = "hello dotnet";
            sw.WriteLine(str);
            sw.Flush();
            fs.Close();
            MessageBox.Show("File created");

        }

        private void btn_streamreader_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("c:Test/b.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            StreamReader sr = new StreamReader(fs);
            string str = sr.ReadToEnd();
            fs.Close();
            MessageBox.Show(str);
        }
    }
}
