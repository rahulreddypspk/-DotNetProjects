﻿namespace win_salary_calc
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_days = new System.Windows.Forms.Label();
            this.lbl_per_day_salary = new System.Windows.Forms.Label();
            this.txt_days = new System.Windows.Forms.TextBox();
            this.txt_per_day_salary = new System.Windows.Forms.TextBox();
            this.btn_getsalary = new System.Windows.Forms.Button();
            this.lbl_salary = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_days
            // 
            this.lbl_days.AutoSize = true;
            this.lbl_days.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_days.Location = new System.Drawing.Point(131, 48);
            this.lbl_days.Name = "lbl_days";
            this.lbl_days.Size = new System.Drawing.Size(85, 31);
            this.lbl_days.TabIndex = 0;
            this.lbl_days.Text = "Days:";
            // 
            // lbl_per_day_salary
            // 
            this.lbl_per_day_salary.AutoSize = true;
            this.lbl_per_day_salary.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_per_day_salary.Location = new System.Drawing.Point(12, 109);
            this.lbl_per_day_salary.Name = "lbl_per_day_salary";
            this.lbl_per_day_salary.Size = new System.Drawing.Size(204, 31);
            this.lbl_per_day_salary.TabIndex = 1;
            this.lbl_per_day_salary.Text = "Per Day Salary:";
            // 
            // txt_days
            // 
            this.txt_days.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_days.Location = new System.Drawing.Point(255, 56);
            this.txt_days.Name = "txt_days";
            this.txt_days.Size = new System.Drawing.Size(160, 26);
            this.txt_days.TabIndex = 2;
            // 
            // txt_per_day_salary
            // 
            this.txt_per_day_salary.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_per_day_salary.Location = new System.Drawing.Point(259, 117);
            this.txt_per_day_salary.Name = "txt_per_day_salary";
            this.txt_per_day_salary.Size = new System.Drawing.Size(156, 26);
            this.txt_per_day_salary.TabIndex = 3;
            // 
            // btn_getsalary
            // 
            this.btn_getsalary.Location = new System.Drawing.Point(156, 207);
            this.btn_getsalary.Name = "btn_getsalary";
            this.btn_getsalary.Size = new System.Drawing.Size(137, 41);
            this.btn_getsalary.TabIndex = 4;
            this.btn_getsalary.Text = "Get Salary";
            this.btn_getsalary.UseVisualStyleBackColor = true;
            this.btn_getsalary.Click += new System.EventHandler(this.btn_getsalary_Click);
            // 
            // lbl_salary
            // 
            this.lbl_salary.AutoSize = true;
            this.lbl_salary.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_salary.Location = new System.Drawing.Point(396, 212);
            this.lbl_salary.Name = "lbl_salary";
            this.lbl_salary.Size = new System.Drawing.Size(61, 20);
            this.lbl_salary.TabIndex = 5;
            this.lbl_salary.Text = "Salary:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(818, 294);
            this.Controls.Add(this.lbl_salary);
            this.Controls.Add(this.btn_getsalary);
            this.Controls.Add(this.txt_per_day_salary);
            this.Controls.Add(this.txt_days);
            this.Controls.Add(this.lbl_per_day_salary);
            this.Controls.Add(this.lbl_days);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_days;
        private System.Windows.Forms.Label lbl_per_day_salary;
        private System.Windows.Forms.TextBox txt_days;
        private System.Windows.Forms.TextBox txt_per_day_salary;
        private System.Windows.Forms.Button btn_getsalary;
        private System.Windows.Forms.Label lbl_salary;
    }
}

