﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace win_salary_calc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_getsalary_Click(object sender, EventArgs e)
        {
            if(txt_days.Text==string.Empty)
            {
                MessageBox.Show("Enter Days:");
            }
            else if(txt_per_day_salary.Text==string.Empty)
            {
                MessageBox.Show("enter per day salary:");
            }
            else
            {
                int days = Convert.ToInt32(txt_days.Text);
                int per_day_salary = Convert.ToInt32(txt_per_day_salary.Text);

                SalaryLibrary.Salary obj = new SalaryLibrary.Salary();
                int total = obj.GetSalary(days, per_day_salary);
                lbl_salary.Text = total.ToString();
            }
        }
    }
}
