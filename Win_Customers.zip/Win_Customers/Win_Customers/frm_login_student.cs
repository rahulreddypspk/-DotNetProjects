﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Customers
{
    public partial class frm_login_student : Form
    {
        public frm_login_student()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            int ID = Convert.ToInt32(txt_login.Text);
            string Password = txt_password.Text;

            CustomerDAL dal = new CustomerDAL();
            bool status = dal.login(ID, Password);
            if(status)
            {
                MessageBox.Show("valid user");

            }
            else
            {
                MessageBox.Show("Invalid user");
            }
        }

        private void dg_customer_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            CustomerDAL dal = new CustomerDAL();
            string city = txt_employeecity.Text;
            List<Customers> list = dal.showcustomer(city);
            dg_customer.DataSource = list;
        }
    }
}
