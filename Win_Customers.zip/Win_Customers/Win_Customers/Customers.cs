﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_Customers
{
    class Customers
    {
        public int CustomerID { get; set; }

        public string CustomerName { get; set; }

        public string CustomerPassword { get; set; }

        public string CustomerCity { get; set; }

        public string CustomerAddress { get; set; }

        public string CustomerMObileNO { get; set; }

        public string CustomerEmailID { get; set; }
    }
}
