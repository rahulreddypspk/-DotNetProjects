﻿namespace Win_Customers
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_customerid = new System.Windows.Forms.Label();
            this.lbl_customername = new System.Windows.Forms.Label();
            this.lbl_customerpassword = new System.Windows.Forms.Label();
            this.lbl_customercity = new System.Windows.Forms.Label();
            this.lbl_customeraddress = new System.Windows.Forms.Label();
            this.lbl_customermobileno = new System.Windows.Forms.Label();
            this.lbl_customeremailid = new System.Windows.Forms.Label();
            this.txt_customerid = new System.Windows.Forms.TextBox();
            this.txt_customername = new System.Windows.Forms.TextBox();
            this.txt_customerpassword = new System.Windows.Forms.TextBox();
            this.txt_customercity = new System.Windows.Forms.TextBox();
            this.txt_customeraddress = new System.Windows.Forms.TextBox();
            this.txt_customermobileno = new System.Windows.Forms.TextBox();
            this.txt_customeremailid = new System.Windows.Forms.TextBox();
            this.btn_add = new System.Windows.Forms.Button();
            this.btn_find = new System.Windows.Forms.Button();
            this.btn_update = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_reset = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_customerid
            // 
            this.lbl_customerid.AutoSize = true;
            this.lbl_customerid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customerid.Location = new System.Drawing.Point(99, 35);
            this.lbl_customerid.Name = "lbl_customerid";
            this.lbl_customerid.Size = new System.Drawing.Size(161, 29);
            this.lbl_customerid.TabIndex = 0;
            this.lbl_customerid.Text = "Customer ID:";
            this.lbl_customerid.Click += new System.EventHandler(this.lbl_customerid_Click);
            // 
            // lbl_customername
            // 
            this.lbl_customername.AutoSize = true;
            this.lbl_customername.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customername.Location = new System.Drawing.Point(55, 100);
            this.lbl_customername.Name = "lbl_customername";
            this.lbl_customername.Size = new System.Drawing.Size(205, 29);
            this.lbl_customername.TabIndex = 1;
            this.lbl_customername.Text = "Customer Name:";
            // 
            // lbl_customerpassword
            // 
            this.lbl_customerpassword.AutoSize = true;
            this.lbl_customerpassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customerpassword.Location = new System.Drawing.Point(12, 165);
            this.lbl_customerpassword.Name = "lbl_customerpassword";
            this.lbl_customerpassword.Size = new System.Drawing.Size(248, 29);
            this.lbl_customerpassword.TabIndex = 2;
            this.lbl_customerpassword.Text = "Customer Password:";
            // 
            // lbl_customercity
            // 
            this.lbl_customercity.AutoSize = true;
            this.lbl_customercity.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customercity.Location = new System.Drawing.Point(79, 227);
            this.lbl_customercity.Name = "lbl_customercity";
            this.lbl_customercity.Size = new System.Drawing.Size(181, 29);
            this.lbl_customercity.TabIndex = 3;
            this.lbl_customercity.Text = "Customer City:";
            // 
            // lbl_customeraddress
            // 
            this.lbl_customeraddress.AutoSize = true;
            this.lbl_customeraddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customeraddress.Location = new System.Drawing.Point(30, 290);
            this.lbl_customeraddress.Name = "lbl_customeraddress";
            this.lbl_customeraddress.Size = new System.Drawing.Size(230, 29);
            this.lbl_customeraddress.TabIndex = 4;
            this.lbl_customeraddress.Text = "Customer Address:";
            // 
            // lbl_customermobileno
            // 
            this.lbl_customermobileno.AutoSize = true;
            this.lbl_customermobileno.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customermobileno.Location = new System.Drawing.Point(11, 354);
            this.lbl_customermobileno.Name = "lbl_customermobileno";
            this.lbl_customermobileno.Size = new System.Drawing.Size(249, 29);
            this.lbl_customermobileno.TabIndex = 5;
            this.lbl_customermobileno.Text = "Customer MobileNO:";
            // 
            // lbl_customeremailid
            // 
            this.lbl_customeremailid.AutoSize = true;
            this.lbl_customeremailid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customeremailid.Location = new System.Drawing.Point(34, 408);
            this.lbl_customeremailid.Name = "lbl_customeremailid";
            this.lbl_customeremailid.Size = new System.Drawing.Size(226, 29);
            this.lbl_customeremailid.TabIndex = 6;
            this.lbl_customeremailid.Text = "Customer EmailID:";
            // 
            // txt_customerid
            // 
            this.txt_customerid.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customerid.Location = new System.Drawing.Point(278, 41);
            this.txt_customerid.Name = "txt_customerid";
            this.txt_customerid.Size = new System.Drawing.Size(192, 26);
            this.txt_customerid.TabIndex = 7;
            // 
            // txt_customername
            // 
            this.txt_customername.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customername.Location = new System.Drawing.Point(278, 107);
            this.txt_customername.Name = "txt_customername";
            this.txt_customername.Size = new System.Drawing.Size(192, 26);
            this.txt_customername.TabIndex = 8;
            // 
            // txt_customerpassword
            // 
            this.txt_customerpassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customerpassword.Location = new System.Drawing.Point(278, 169);
            this.txt_customerpassword.Name = "txt_customerpassword";
            this.txt_customerpassword.Size = new System.Drawing.Size(192, 26);
            this.txt_customerpassword.TabIndex = 9;
            // 
            // txt_customercity
            // 
            this.txt_customercity.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customercity.Location = new System.Drawing.Point(278, 232);
            this.txt_customercity.Name = "txt_customercity";
            this.txt_customercity.Size = new System.Drawing.Size(192, 26);
            this.txt_customercity.TabIndex = 10;
            // 
            // txt_customeraddress
            // 
            this.txt_customeraddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customeraddress.Location = new System.Drawing.Point(278, 297);
            this.txt_customeraddress.Name = "txt_customeraddress";
            this.txt_customeraddress.Size = new System.Drawing.Size(192, 26);
            this.txt_customeraddress.TabIndex = 11;
            // 
            // txt_customermobileno
            // 
            this.txt_customermobileno.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customermobileno.Location = new System.Drawing.Point(278, 360);
            this.txt_customermobileno.Name = "txt_customermobileno";
            this.txt_customermobileno.Size = new System.Drawing.Size(192, 26);
            this.txt_customermobileno.TabIndex = 12;
            // 
            // txt_customeremailid
            // 
            this.txt_customeremailid.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customeremailid.Location = new System.Drawing.Point(278, 416);
            this.txt_customeremailid.Name = "txt_customeremailid";
            this.txt_customeremailid.Size = new System.Drawing.Size(192, 26);
            this.txt_customeremailid.TabIndex = 13;
            // 
            // btn_add
            // 
            this.btn_add.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_add.Location = new System.Drawing.Point(634, 41);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(165, 62);
            this.btn_add.TabIndex = 14;
            this.btn_add.Text = "ADD";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // btn_find
            // 
            this.btn_find.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_find.Location = new System.Drawing.Point(634, 148);
            this.btn_find.Name = "btn_find";
            this.btn_find.Size = new System.Drawing.Size(165, 68);
            this.btn_find.TabIndex = 15;
            this.btn_find.Text = "FIND";
            this.btn_find.UseVisualStyleBackColor = true;
            this.btn_find.Click += new System.EventHandler(this.btn_find_Click);
            // 
            // btn_update
            // 
            this.btn_update.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_update.Location = new System.Drawing.Point(634, 258);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(165, 65);
            this.btn_update.TabIndex = 16;
            this.btn_update.Text = "UPDATE";
            this.btn_update.UseVisualStyleBackColor = true;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_delete.Location = new System.Drawing.Point(634, 363);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(165, 74);
            this.btn_delete.TabIndex = 17;
            this.btn_delete.Text = "DELETE";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_reset
            // 
            this.btn_reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_reset.Location = new System.Drawing.Point(872, 267);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(85, 91);
            this.btn_reset.TabIndex = 18;
            this.btn_reset.Text = "RESET";
            this.btn_reset.UseVisualStyleBackColor = true;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(969, 446);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_update);
            this.Controls.Add(this.btn_find);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.txt_customeremailid);
            this.Controls.Add(this.txt_customermobileno);
            this.Controls.Add(this.txt_customeraddress);
            this.Controls.Add(this.txt_customercity);
            this.Controls.Add(this.txt_customerpassword);
            this.Controls.Add(this.txt_customername);
            this.Controls.Add(this.txt_customerid);
            this.Controls.Add(this.lbl_customeremailid);
            this.Controls.Add(this.lbl_customermobileno);
            this.Controls.Add(this.lbl_customeraddress);
            this.Controls.Add(this.lbl_customercity);
            this.Controls.Add(this.lbl_customerpassword);
            this.Controls.Add(this.lbl_customername);
            this.Controls.Add(this.lbl_customerid);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_customerid;
        private System.Windows.Forms.Label lbl_customername;
        private System.Windows.Forms.Label lbl_customerpassword;
        private System.Windows.Forms.Label lbl_customercity;
        private System.Windows.Forms.Label lbl_customeraddress;
        private System.Windows.Forms.Label lbl_customermobileno;
        private System.Windows.Forms.Label lbl_customeremailid;
        private System.Windows.Forms.TextBox txt_customerid;
        private System.Windows.Forms.TextBox txt_customername;
        private System.Windows.Forms.TextBox txt_customerpassword;
        private System.Windows.Forms.TextBox txt_customercity;
        private System.Windows.Forms.TextBox txt_customeraddress;
        private System.Windows.Forms.TextBox txt_customermobileno;
        private System.Windows.Forms.TextBox txt_customeremailid;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Button btn_find;
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_reset;
    }
}

