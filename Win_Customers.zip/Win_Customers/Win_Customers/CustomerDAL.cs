﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;// dll ref
using System.Data;

namespace Win_Customers
{
    class CustomerDAL
    {
        SqlConnection con = new SqlConnection
            (ConfigurationManager.ConnectionStrings["cust"].ConnectionString);

        public int AddCustomer(Customers obj)
        {
            SqlCommand cust_insert = new SqlCommand("add_customer", con);
            cust_insert.Parameters.AddWithValue("@name", obj.CustomerName);
            cust_insert.Parameters.AddWithValue("@password", obj.CustomerPassword);
            cust_insert.Parameters.AddWithValue("@city", obj.CustomerCity);
            cust_insert.Parameters.AddWithValue("@address", obj.CustomerAddress);
            cust_insert.Parameters.AddWithValue("@mobileno", obj.CustomerMObileNO);
            cust_insert.Parameters.AddWithValue("@emailid", obj.CustomerEmailID);

            cust_insert.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();

            retdata.Direction = ParameterDirection.ReturnValue;
            cust_insert.Parameters.Add(retdata);
            con.Open();
            cust_insert.ExecuteNonQuery();
            con.Close();

            int ID = Convert.ToInt32(retdata.Value);
            return ID;

        }
        public Customers Find(int ID)
        {
            SqlCommand cust_find = new SqlCommand(" find_customer", con);
            cust_find.Parameters.AddWithValue("@id", ID);

            cust_find.CommandType = CommandType.StoredProcedure;

            con.Open();
            SqlDataReader dr = cust_find.ExecuteReader();
            if(dr.Read())
            {
                Customers c = new Customers();
                
                c.CustomerID = dr.GetInt32(0);
                c.CustomerName = dr.GetString(1);
                c.CustomerPassword = dr.GetString(2);
                c.CustomerCity = dr.GetString(3);
                c.CustomerAddress = dr.GetString(4);
                c.CustomerMObileNO = dr.GetString(5);
                c.CustomerEmailID = dr.GetString(6);
                con.Close();
                return c;
            }
            else
            {
                return null;
            }

            }
        public bool Update(int id,string password,string city)
        {
            SqlCommand cust_update = new SqlCommand("update_customer", con);
            cust_update.Parameters.AddWithValue("@id", id);
            cust_update.Parameters.AddWithValue("@password", password);
            cust_update.Parameters.AddWithValue("@city", city);

            cust_update.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            cust_update.Parameters.Add(retdata);    
            con.Open();
            cust_update.ExecuteNonQuery();
            con.Close();
            int count = Convert.ToInt32(retdata.Value);
            if(count>0)
            {
                return true;
            }
            else
            {
                return false;
            }
         }

        public bool Delete(int id)
        {
            SqlCommand cust_delete = new SqlCommand("delete_customer", con);
            cust_delete.Parameters.AddWithValue("@id", id);

            cust_delete.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;

            cust_delete.Parameters.Add(retdata);
            con.Open();
             cust_delete.ExecuteNonQuery();
            con.Close();
            int count = Convert.ToInt32(retdata.Value);
            if(count>0)
            {
                return true;

            }
            else
            {
                return false;
            }
        }


        public List<Customers> ShowCustomer(string city)
        {
            SqlCommand show_employees = new SqlCommand("show_customercity", con);
            show_employees.Parameters.AddWithValue("@city", city);
            show_employees.CommandType = CommandType.StoredProcedure;

            con.Open();
            SqlDataReader dr = show_employees.ExecuteReader();

            List<Customers> custlist = new List<Customers>();

            while (dr.Read())
            {
                Customers obj = new Customers();

                obj.CustomerID = dr.GetInt32(0);
                obj.CustomerName = dr.GetString(1);
                obj.CustomerPassword = dr.GetString(2);
                obj.CustomerCity = dr.GetString(3);
                obj.CustomerAddress = dr.GetString(4);
                obj.CustomerMObileNO = dr.GetString(5);
                obj.CustomerEmailID = dr.GetString(6);

                custlist.Add(obj);
            }
            con.Close();
            return custlist;

        }


        public bool login(int ID,string Password)
        {
            SqlCommand cust_login = new SqlCommand("login_customer", con);
            cust_login.Parameters.AddWithValue("@id", ID);
            cust_login.Parameters.AddWithValue("@password", Password);
            cust_login.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            cust_login.Parameters.Add(retdata);

            con.Open();
            cust_login.ExecuteNonQuery();
            con.Close();

            int count = Convert.ToInt32(retdata.Value);
            if(count>0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        public List<Customers> showcustomer(string city)
        {
            SqlCommand show_customer = new SqlCommand("show_customer", con);
            show_customer.Parameters.AddWithValue("@city", city);
            show_customer.CommandType = CommandType.StoredProcedure;

            con.Open();
            SqlDataReader dr = show_customer.ExecuteReader();

            List<Customers> custlist = new List<Customers>();

            while(dr.Read())
            {
                Customers obj = new Customers();

                obj.CustomerID = dr.GetInt32(0);
                obj.CustomerName = dr.GetString(1);
                obj.CustomerPassword = dr.GetString(2);
                obj.CustomerCity = dr.GetString(3);
                obj.CustomerAddress = dr.GetString(4);
                obj.CustomerMObileNO = dr.GetString(5);
                obj.CustomerEmailID = dr.GetString(6);

                custlist.Add(obj);

            }
            con.Close();
            return custlist;
        }
    }
}
