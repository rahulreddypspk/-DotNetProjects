﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Customers
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void lbl_customerid_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            if(txt_customername.Text==String.Empty)
            {
                MessageBox.Show("enter name");
               
            }
            else if(txt_customerpassword.Text==String.Empty)
            {
                MessageBox.Show("enter password");
            }
            else if(txt_customercity.Text==String.Empty)
            {
                MessageBox.Show("enter city");

            }
            else if(txt_customeraddress.Text==String.Empty)
            {
                MessageBox.Show("enter address");
            }
            else if(txt_customermobileno.Text==String.Empty)
            {
                MessageBox.Show("enter mobile no");
            }
            else if(txt_customeremailid.Text==String.Empty)
            {
                MessageBox.Show("enter email");
            }
            else
            {
                string name = txt_customername.Text;
                string password = txt_customerpassword.Text;
                string city = txt_customercity.Text;
                string address = txt_customeraddress.Text;
                string moblieno = txt_customermobileno.Text;
                string emailid = txt_customeremailid.Text;

                Customers obj = new Customers();
                obj.CustomerName = name;
                obj.CustomerPassword = password;
                obj.CustomerCity = city;
                obj.CustomerAddress = address;
                obj.CustomerMObileNO = moblieno;
                obj.CustomerEmailID = emailid;
               
                CustomerDAL dal = new CustomerDAL();
                int id = dal.AddCustomer(obj);
                MessageBox.Show("Customer added:" + id);



            }

        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            if(txt_customerid.Text==String.Empty)
            {
                MessageBox.Show("enter id");
            }
            else if(txt_customercity.Text==String.Empty)
            {
                MessageBox.Show("enter city");
            }
            else if(txt_customerpassword.Text==String.Empty)
            {
                MessageBox.Show("enter password");

            }
            else
            {
                int id = Convert.ToInt32(txt_customerid.Text);
                string city = txt_customercity.Text;
                string password = txt_customerpassword.Text;

                CustomerDAL dal = new CustomerDAL();
                bool status = dal.Update(id, city, password);
                    if(status)
                {
                    MessageBox.Show("updated");
                }else
                {
                    MessageBox.Show("not updated");
                }
            }
        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            if(txt_customerid.Text==String.Empty)
            {
                MessageBox.Show("enter id");

            }
            else
            {
                int id = Convert.ToInt32(txt_customerid.Text);
                CustomerDAL dal = new CustomerDAL();
                Customers cust = dal.Find(id);
                if(cust!=null)
                {
                    txt_customername.Text = cust.CustomerName;
                    txt_customerpassword.Text = cust.CustomerPassword;
                    txt_customercity.Text = cust.CustomerCity;
                    txt_customeraddress.Text = cust.CustomerAddress;
                    txt_customermobileno.Text = cust.CustomerMObileNO;
                    txt_customeremailid.Text = cust.CustomerEmailID;

                }
                else
                {
                    MessageBox.Show("not found");
                }

            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if(txt_customerid.Text==String.Empty)
            {
                MessageBox.Show("enter id");
            }
            else
            {
                int id = Convert.ToInt32(txt_customerid.Text);
                CustomerDAL dal = new CustomerDAL();
                bool status = dal.Delete(id);
                if(status)
                {
                    MessageBox.Show("deleted");

                }
                else
                {
                    MessageBox.Show("not deleted");
                }
            }
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            txt_customerid.Text = string.Empty;
            txt_customername.Text = string.Empty;
            txt_customerpassword.Text = string.Empty;
            txt_customercity.Text = string.Empty;
            txt_customeraddress.Text = string.Empty;
            txt_customermobileno.Text = string.Empty;
            txt_customeremailid.Text = string.Empty;
        }
    }
}