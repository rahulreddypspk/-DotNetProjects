create database EMP_DB


create table Employees
(EmployeeID int,
EmployeeFName varchar(100),
EmployeeLName varchar(100),
EmployeeCity varchar(100),
EmployeeDOB dateTime,
EmployeeSalary int,
EmployeeStatus varchar(100))

alter table Employees add EmployeeDEP varchar(100),EmployeeDOJ varchar(100)

select * from Employees

insert Employees values(1001,'rahul','reddy','HYD','11-25-1996',25000,
'working','DOTDevaloper','10-31-2018')
insert Employees values(1002,'kanak','chowdary','HYD','12-23-1997',20000,
'Working','PHPDevaloper','10-31-2018')
insert Employees values(10003,'prabath','reddy','Warangal','11-11-1996',30000,
'resigned','JAVADevaloper','12-12-1999')
insert Employees values(1004,'manish','chowdary','guntur','12-12-1994',50000,
'Working','HTMLTestor','07-07-2000')
insert Employees values(1005,'vikram','guram','WNP','07-07-1994',25000,
'Working','c++','08-08-2005')
insert Employees values(1006,'vamshi','potti','KODHADA','01-01-1992',30000,
'resigned','TESTING','02-02-2003')
insert Employees values(1007,'kranthi','reddy','HYD','08-08-1998',100000,
'Working','C#','03-03-2011')
insert Employees values(1007,'haneesha','reddy','goa','05-05-1996',50000,
'resigned','JavaDevaloper','01-01-2017')
insert Employees values(1008,'vikey','Rao','bangalore','04-04-1992',60000,
'Working','PHPDevaloper','07-07-2013')
insert Employees values(1009,'Raju','Rao','KARNATAKA','02-02-1996',70000,
'resigned','DOTNETDevaloper','09-09-2009')
insert Employees values(1010,'ram','reddy','HYD','04-04-1998',25000,
'Working','PHPDevaloper','01-01-2013')


select * from Employees

select * from Employees where EmployeeCity='HYD'

select * from Employees where EmployeeSalary between 25000 and 50000

select EmployeeFName,EmployeeLName,EmployeeID,EmployeeCity from Employees

select * from Employees order by len(EmployeeFName)

select  sum(EmployeeSalary)  from Employees

select count(*) from Employees 

select * from Employees where datepart(mm, EmployeeDOJ)=1



select * from Employees  where datediff(yy,EmployeeDOJ,getdate())>5 


select EmployeeDEP, count(*) as 'no of EMP' from Employees group by EmployeeDEP 

select EmployeeCITY ,count(*) as 'count of EMP' from Employees group by EmployeeCity

select * from Employees

update Employees set EmployeeCity='GOA' where EmployeeCity='HYD'


select  EmployeeDEP,sum(EmployeeSalary) from Employees
 group by EmployeeDEP having sum(EmployeeSalary)>50000

 update Employees set EmployeeStatus='resigned' where EmployeeStatus='Working'
 select * from Employees

 select *  from Employees where datediff(mm,EmployeeDOJ,getdate())<=1
 
 
select CAST (employeesalary as decimal(12,4)) from Employees