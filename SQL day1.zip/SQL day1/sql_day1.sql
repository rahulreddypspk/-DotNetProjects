Create Database PathFrontDB

use PathFrontDB

Create Table tbl_Customer
(
CustomerID int,
CustomerName varchar(100),
CustomerCity varchar(100),
CustomerDOB DateTime
)


sp_help tbl_Customer

select * from tbl_Customer


insert tbl_Customer values(1001,'john','chennai','10-22-1991')
insert tbl_Customer values(1002,'rahul','hyderabad','10-24-1998')
insert tbl_Customer values(1003,'reddy','secundrabad','12-12-1997')
insert tbl_Customer values(1004,'varun','goa','11-11-1998')
insert tbl_Customer values(1005,'kanak','pune','12-03-1989')
insert tbl_Customer values(1006,'manish','aus',null)
insert tbl_Customer(CustomerID,CustomerName)values(1007,'abc')


select * from tbl_Customer

select CustomerID,CustomerName from tbl_Customer

select * from tbl_Customer where CustomerCity='chennai' 

update tbl_Customer set CustomerCity='hyd',CustomerName='xyz' where CustomerID=1001

select * from tbl_Customer

delete tbl_Customer where CustomerID=1001


truncate table tbl_customer

alter table tbl_customer add customeremail varchar(100)

alter table tbl_customer drop column CustomerEmail

select * from tbl_Customer


alter table tbl_customer alter column CustomerName varchar(200)

select * from tbl_Customer where CustomerCity in('chennai','pune')

select * from tbl_Customer where CustomerCity is null

select * from tbl_Customer where CustomerDOB between '11-11-1997' and '12-12-1996'

select * from tbl_Customer order by CustomerDOB desc

select * from tbl_Customer order by CustomerName asc

select * from tbl_Customer order by CustomerDOB asc


select * from tbl_Customer order by CustomerDOB asc ,CustomerCity desc

select top 1* from tbl_Customer order by CustomerDOB desc

select top 1* from tbl_Customer  order by len(CustomerName) desc

select len('HELLO')

select substring('hello',1,4)

select lower('HELLO')

select upper('hello')

select left('hello',2)

select right('hello',2)

select isnumeric('12a')

select CEILING(25.11)

select FLOOR(25.99)

select ROUND(253.2150,2)

select ISNULL(customerID ,0)

select * from tbl_customer order by len(Customername) asc 


create table tbl_Employees(EmployeeID int,
EmployeeName varchar(100),
EmployeeCity varchar(100),
EmployeeSalary int
)

insert  tbl_Employees values(1001,'rahul','HYD',20000)
insert tbl_Employees values(1002,'reddy','GOA',30000)
insert tbl_Employees  values(1003,'kanak','Bangalore',40000)
insert tbl_Employees values(1004,'sai','bhihar',50000)
insert tbl_Employees values(1005,'manish','thumkur',60000)


select sum(EmployeeSalary) from tbl_Employees

select max(EmployeeSalary) from tbl_Employees

select min(EmployeeSalary) from tbl_Employees

select avg(EmployeeSalary) from tbl_Employees

select count(*) from tbl_Employees

select getdate()

select * from tbl_Customer

select customerID,customerName, datediff(yy,CustomerDOB,getdate()) from tbl_Customer



select customerID,customerName, datediff(yy,CustomerDOB,getdate()) as 'age',
 datename(dw,customerDOB) as 'day',datepart(dw,customerdob) as 'number'
from tbl_Customer

select CustomerName , datename(dw,CustomerDOB),datepart(dw,CustomerDOB) from tbl_Customer 

select dateadd(mm,10,Customerdob) from tbl_Customer

select dateadd(yy,-2,Customerdob) from tbl_Customer 

select CONVERT(varchar(10),employeesalary) from tbl_Employees

select CAST (employeesalary as decimal(12,2)) from tbl_Employees

select EmployeeCity ,count(*) from tbl_Employees group by EmployeeCity


select Employeecity,EmployeeSalary,count(*),avg(EmployeeSalary) as 'avg' 
from tbl_Employees group by EmployeeCity,EmployeeSalary

select EmployeeCity,EmployeeSalary , count (*),max(EmployeeSalary)  
from tbl_Employees group by EmployeeCity,EmployeeSalary

select employeecity,count(*) from tbl_Employees where EmployeeSalary>10000
group by EmployeeCity

select employeecity,count(*) from tbl_Employees where EmployeeSalary>10000
group by EmployeeCity having count(*)>=1

