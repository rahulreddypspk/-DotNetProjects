﻿namespace Win_ado
{
    partial class new_frm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_employeepassword = new System.Windows.Forms.TextBox();
            this.txt_employeecity = new System.Windows.Forms.TextBox();
            this.txt_empname = new System.Windows.Forms.TextBox();
            this.lbl_emppassword = new System.Windows.Forms.Label();
            this.lbl_empcity = new System.Windows.Forms.Label();
            this.lbl_empname = new System.Windows.Forms.Label();
            this.lbl_employeeid = new System.Windows.Forms.Label();
            this.txt_employeeid = new System.Windows.Forms.TextBox();
            this.lbl_employeedoj = new System.Windows.Forms.Label();
            this.txt_employeedoj = new System.Windows.Forms.TextBox();
            this.btnfind = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_update = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt_employeepassword
            // 
            this.txt_employeepassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_employeepassword.Location = new System.Drawing.Point(291, 214);
            this.txt_employeepassword.Name = "txt_employeepassword";
            this.txt_employeepassword.Size = new System.Drawing.Size(206, 26);
            this.txt_employeepassword.TabIndex = 13;
            // 
            // txt_employeecity
            // 
            this.txt_employeecity.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_employeecity.Location = new System.Drawing.Point(290, 144);
            this.txt_employeecity.Name = "txt_employeecity";
            this.txt_employeecity.Size = new System.Drawing.Size(207, 26);
            this.txt_employeecity.TabIndex = 12;
            // 
            // txt_empname
            // 
            this.txt_empname.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_empname.Location = new System.Drawing.Point(291, 78);
            this.txt_empname.Name = "txt_empname";
            this.txt_empname.Size = new System.Drawing.Size(206, 26);
            this.txt_empname.TabIndex = 11;
            // 
            // lbl_emppassword
            // 
            this.lbl_emppassword.AutoSize = true;
            this.lbl_emppassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_emppassword.Location = new System.Drawing.Point(12, 209);
            this.lbl_emppassword.Name = "lbl_emppassword";
            this.lbl_emppassword.Size = new System.Drawing.Size(252, 29);
            this.lbl_emppassword.TabIndex = 10;
            this.lbl_emppassword.Text = "Employee Password:";
            this.lbl_emppassword.Click += new System.EventHandler(this.lbl_emppassword_Click);
            // 
            // lbl_empcity
            // 
            this.lbl_empcity.AutoSize = true;
            this.lbl_empcity.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_empcity.Location = new System.Drawing.Point(76, 141);
            this.lbl_empcity.Name = "lbl_empcity";
            this.lbl_empcity.Size = new System.Drawing.Size(185, 29);
            this.lbl_empcity.TabIndex = 9;
            this.lbl_empcity.Text = "Employee City:";
            // 
            // lbl_empname
            // 
            this.lbl_empname.AutoSize = true;
            this.lbl_empname.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_empname.Location = new System.Drawing.Point(52, 78);
            this.lbl_empname.Name = "lbl_empname";
            this.lbl_empname.Size = new System.Drawing.Size(209, 29);
            this.lbl_empname.TabIndex = 8;
            this.lbl_empname.Text = "Employee Name:";
            this.lbl_empname.Click += new System.EventHandler(this.lbl_empname_Click);
            // 
            // lbl_employeeid
            // 
            this.lbl_employeeid.AutoSize = true;
            this.lbl_employeeid.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_employeeid.Location = new System.Drawing.Point(84, 24);
            this.lbl_employeeid.Name = "lbl_employeeid";
            this.lbl_employeeid.Size = new System.Drawing.Size(177, 31);
            this.lbl_employeeid.TabIndex = 16;
            this.lbl_employeeid.Text = "Employee ID:";
            // 
            // txt_employeeid
            // 
            this.txt_employeeid.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_employeeid.Location = new System.Drawing.Point(290, 36);
            this.txt_employeeid.Name = "txt_employeeid";
            this.txt_employeeid.Size = new System.Drawing.Size(207, 26);
            this.txt_employeeid.TabIndex = 17;
            // 
            // lbl_employeedoj
            // 
            this.lbl_employeedoj.AutoSize = true;
            this.lbl_employeedoj.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_employeedoj.Location = new System.Drawing.Point(60, 271);
            this.lbl_employeedoj.Name = "lbl_employeedoj";
            this.lbl_employeedoj.Size = new System.Drawing.Size(191, 29);
            this.lbl_employeedoj.TabIndex = 18;
            this.lbl_employeedoj.Text = "Employee DOJ:";
            // 
            // txt_employeedoj
            // 
            this.txt_employeedoj.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_employeedoj.Location = new System.Drawing.Point(291, 280);
            this.txt_employeedoj.Name = "txt_employeedoj";
            this.txt_employeedoj.Size = new System.Drawing.Size(206, 26);
            this.txt_employeedoj.TabIndex = 19;
            // 
            // btnfind
            // 
            this.btnfind.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnfind.Location = new System.Drawing.Point(657, 82);
            this.btnfind.Name = "btnfind";
            this.btnfind.Size = new System.Drawing.Size(113, 49);
            this.btnfind.TabIndex = 20;
            this.btnfind.Text = "FIND";
            this.btnfind.UseVisualStyleBackColor = true;
            this.btnfind.Click += new System.EventHandler(this.btnfind_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_delete.Location = new System.Drawing.Point(657, 172);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(113, 53);
            this.btn_delete.TabIndex = 21;
            this.btn_delete.Text = "DELETE";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_update
            // 
            this.btn_update.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_update.Location = new System.Drawing.Point(657, 249);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(113, 57);
            this.btn_update.TabIndex = 22;
            this.btn_update.Text = "UPDATE";
            this.btn_update.UseVisualStyleBackColor = true;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // new_frm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1007, 439);
            this.Controls.Add(this.btn_update);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btnfind);
            this.Controls.Add(this.txt_employeedoj);
            this.Controls.Add(this.lbl_employeedoj);
            this.Controls.Add(this.txt_employeeid);
            this.Controls.Add(this.lbl_employeeid);
            this.Controls.Add(this.txt_employeepassword);
            this.Controls.Add(this.txt_employeecity);
            this.Controls.Add(this.txt_empname);
            this.Controls.Add(this.lbl_emppassword);
            this.Controls.Add(this.lbl_empcity);
            this.Controls.Add(this.lbl_empname);
            this.Name = "new_frm";
            this.Text = "new_frm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txt_employeepassword;
        private System.Windows.Forms.TextBox txt_employeecity;
        private System.Windows.Forms.TextBox txt_empname;
        private System.Windows.Forms.Label lbl_emppassword;
        private System.Windows.Forms.Label lbl_empcity;
        private System.Windows.Forms.Label lbl_empname;
        private System.Windows.Forms.Label lbl_employeeid;
        private System.Windows.Forms.TextBox txt_employeeid;
        private System.Windows.Forms.Label lbl_employeedoj;
        private System.Windows.Forms.TextBox txt_employeedoj;
        private System.Windows.Forms.Button btnfind;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_update;
    }
}