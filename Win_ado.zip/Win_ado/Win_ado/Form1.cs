﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_ado
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            txt_empname.Text = string.Empty;
            txt_employeecity.Text = string.Empty;
            txt_employeepassword.Text = string.Empty;
        }

        private void btn_newemployee_Click(object sender, EventArgs e)
        {
            if(txt_empname.Text==string.Empty)
            {
                MessageBox.Show("enter name");
            }
            else if(txt_employeecity.Text==string.Empty)
            {
                MessageBox.Show("enter city");

            }
            else if(txt_employeepassword.Text==string.Empty)
            {
                MessageBox.Show("enter password");
            }
            else
            {
                string name = txt_empname.Text;
                string city = txt_employeecity.Text;
                string password = txt_employeepassword.Text;
                Employee obj = new Employee();
                obj.EmployeeName = name;
                obj.EmployeeCity = city;
                obj.EmployeePassword = password;

                EmployeeDAL dal = new EmployeeDAL();
                int id = dal.AddEmployee(obj);
                MessageBox.Show("Employee added:" + id);
               
            }
        }
    }
}
