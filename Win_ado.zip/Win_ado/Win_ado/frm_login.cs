﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_ado
{
    public partial class frm_login : Form
    {
        public frm_login()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            int ID = Convert.ToInt32(txt_loginid.Text);
            string password = txt_password.Text;
            try
            {
                EmployeeDAL dal = new EmployeeDAL();
                bool satus = dal.Login(ID, password);
                if (satus)
                {
                    MessageBox.Show("valid user");
                }
                else
                {
                    MessageBox.Show("Invalid user");
                }

            }
           
            catch(System.Data.SqlClient.SqlException exp)
            {
                MessageBox.Show("Sql error");
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
            finally
            {
                MessageBox.Show("finally block");
            }
            
        }


        private void btn_login_with_sql_injection_Click(object sender, EventArgs e)
        {
            string id = txt_loginid.Text;
            string password = txt_password.Text;

            EmployeeDAL dal = new EmployeeDAL();
            bool status = dal.LoginSqlInjection(id, password);
            if(status)
            {
                MessageBox.Show("Valid user");
            }
            else
            {
                MessageBox.Show("invalid user");
            }
        }
    }
}
