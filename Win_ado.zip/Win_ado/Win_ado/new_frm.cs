﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_ado
{
    public partial class new_frm : Form
    {
        public new_frm()
        {
            InitializeComponent();
        }

        private void lbl_empname_Click(object sender, EventArgs e)
        {

        }

        private void lbl_emppassword_Click(object sender, EventArgs e)
        {

        }

        private void btnfind_Click(object sender, EventArgs e)
        {
            if (txt_employeeid.Text == string.Empty)
            {
                MessageBox.Show("enter ID");

            }
            else
            {
                int ID = Convert.ToInt32(txt_employeeid.Text);
                EmployeeDAL dal = new EmployeeDAL();
                Employee emp = dal.Find(ID);
                if (emp != null)
                {
                    txt_empname.Text = emp.EmployeeName;
                    txt_employeepassword.Text = emp.EmployeePassword;
                    txt_employeecity.Text = emp.EmployeeCity;
                    txt_employeedoj.Text = emp.EmployeeDOJ.ToString();
                }
                else
                {
                    MessageBox.Show("not found");
                }

            }
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            if (txt_employeeid.Text == String.Empty)
            {
                MessageBox.Show("Enter ID");

            }
            else if (txt_employeecity.Text == string.Empty)
            {
                MessageBox.Show("enter city");

            }
            else if (txt_employeepassword.Text == String.Empty)
            {
                MessageBox.Show("enter password");
            }
            else
            {

                int ID = Convert.ToInt32(txt_employeeid.Text);
                string city = txt_employeecity.Text;
                string password = txt_employeepassword.Text;

                EmployeeDAL dal = new EmployeeDAL();
                bool status = dal.update(ID, city, password);
                if (status)
                {
                    MessageBox.Show("Updated");
                     
                }
                else
                {
                    MessageBox.Show("not Updated");
                }

            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (txt_employeeid.Text == String.Empty)
            {
                MessageBox.Show("Enter ID");

            }
            else
            {
                int ID = Convert.ToInt32(txt_employeeid.Text);
                EmployeeDAL dal = new EmployeeDAL();
                bool status = dal.Delete(ID);
                if (status)
                {
                    MessageBox.Show("Deleted");

                }
                else
                {
                    MessageBox.Show("not Found");
                }

            }
        }
        }
    }
