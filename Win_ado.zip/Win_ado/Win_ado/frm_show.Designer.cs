﻿namespace Win_ado
{
    partial class frm_show
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_employeecity = new System.Windows.Forms.Label();
            this.lbl_search = new System.Windows.Forms.Label();
            this.txt_employeecity = new System.Windows.Forms.TextBox();
            this.txt_search = new System.Windows.Forms.TextBox();
            this.btn_find = new System.Windows.Forms.Button();
            this.btn_searchall = new System.Windows.Forms.Button();
            this.dg_employee = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dg_employee)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_employeecity
            // 
            this.lbl_employeecity.AutoSize = true;
            this.lbl_employeecity.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_employeecity.Location = new System.Drawing.Point(53, 60);
            this.lbl_employeecity.Name = "lbl_employeecity";
            this.lbl_employeecity.Size = new System.Drawing.Size(185, 29);
            this.lbl_employeecity.TabIndex = 0;
            this.lbl_employeecity.Text = "Employee City:";
            // 
            // lbl_search
            // 
            this.lbl_search.AutoSize = true;
            this.lbl_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_search.Location = new System.Drawing.Point(82, 153);
            this.lbl_search.Name = "lbl_search";
            this.lbl_search.Size = new System.Drawing.Size(125, 29);
            this.lbl_search.TabIndex = 1;
            this.lbl_search.Text = "SEARCH:";
            this.lbl_search.Click += new System.EventHandler(this.lbl_search_Click);
            // 
            // txt_employeecity
            // 
            this.txt_employeecity.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_employeecity.Location = new System.Drawing.Point(244, 65);
            this.txt_employeecity.Name = "txt_employeecity";
            this.txt_employeecity.Size = new System.Drawing.Size(169, 26);
            this.txt_employeecity.TabIndex = 2;
            // 
            // txt_search
            // 
            this.txt_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_search.Location = new System.Drawing.Point(250, 151);
            this.txt_search.Name = "txt_search";
            this.txt_search.Size = new System.Drawing.Size(163, 26);
            this.txt_search.TabIndex = 3;
            // 
            // btn_find
            // 
            this.btn_find.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_find.Location = new System.Drawing.Point(560, 38);
            this.btn_find.Name = "btn_find";
            this.btn_find.Size = new System.Drawing.Size(140, 62);
            this.btn_find.TabIndex = 4;
            this.btn_find.Text = "FIND";
            this.btn_find.UseVisualStyleBackColor = true;
            this.btn_find.Click += new System.EventHandler(this.btn_find_Click);
            // 
            // btn_searchall
            // 
            this.btn_searchall.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_searchall.Location = new System.Drawing.Point(558, 140);
            this.btn_searchall.Name = "btn_searchall";
            this.btn_searchall.Size = new System.Drawing.Size(142, 62);
            this.btn_searchall.TabIndex = 5;
            this.btn_searchall.Text = "Search(All)";
            this.btn_searchall.UseVisualStyleBackColor = true;
            this.btn_searchall.Click += new System.EventHandler(this.btn_searchall_Click);
            // 
            // dg_employee
            // 
            this.dg_employee.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_employee.Location = new System.Drawing.Point(22, 208);
            this.dg_employee.Name = "dg_employee";
            this.dg_employee.RowTemplate.Height = 24;
            this.dg_employee.Size = new System.Drawing.Size(808, 238);
            this.dg_employee.TabIndex = 6;
            this.dg_employee.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dg_employee_CellContentClick);
            // 
            // frm_show
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(863, 458);
            this.Controls.Add(this.dg_employee);
            this.Controls.Add(this.btn_searchall);
            this.Controls.Add(this.btn_find);
            this.Controls.Add(this.txt_search);
            this.Controls.Add(this.txt_employeecity);
            this.Controls.Add(this.lbl_search);
            this.Controls.Add(this.lbl_employeecity);
            this.Name = "frm_show";
            this.Text = "frm_show";
            ((System.ComponentModel.ISupportInitialize)(this.dg_employee)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_employeecity;
        private System.Windows.Forms.Label lbl_search;
        private System.Windows.Forms.TextBox txt_employeecity;
        private System.Windows.Forms.TextBox txt_search;
        private System.Windows.Forms.Button btn_find;
        private System.Windows.Forms.Button btn_searchall;
        private System.Windows.Forms.DataGridView dg_employee;
    }
}