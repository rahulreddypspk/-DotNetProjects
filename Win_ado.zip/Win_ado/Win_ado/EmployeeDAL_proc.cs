﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace Win_ado
{
    class EmployeeDAL
    {
        SqlConnection con = new SqlConnection
            (ConfigurationManager.ConnectionStrings["Constr"].ConnectionString);

        public int AddEmployee(Employee emp)
        {
            SqlCommand com_emp_insert = new SqlCommand
                 ("proc_addemployee", con);

            com_emp_insert.Parameters.AddWithValue("@name", emp.EmployeeName);
            com_emp_insert.Parameters.AddWithValue("@city", emp.EmployeeCity);
            com_emp_insert.Parameters.AddWithValue("@password", emp.EmployeePassword);

            com_emp_insert.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;

            com_emp_insert.Parameters.Add(retdata);
            con.Open();
            com_emp_insert.ExecuteNonQuery();
            
            con.Close();
            int ID = Convert.ToInt32(retdata.Value);
            return ID;
        }

        public Employee Find(int ID)
        {
            SqlCommand com_find = new SqlCommand
                ("proc_employeedetails", con);
            com_find.Parameters.AddWithValue("@id", ID);
            com_find.CommandType = CommandType.StoredProcedure;

            con.Open();
            SqlDataReader dr = com_find.ExecuteReader();
            if (dr.Read())
            {
                Employee e = new Employee();
                e.EmployeeID = dr.GetInt32(0);
                e.EmployeeName = dr.GetString(1);
                e.EmployeeCity = dr.GetString(2);
                e.EmployeePassword = dr.GetString(3);
                e.EmployeeDOJ = dr.GetDateTime(4);
                con.Close();
                return e;
            }
            else
            {
                return null;
            }
        }


        public bool update(int id, string city, string password)
        {
            SqlCommand com_update = new SqlCommand("proc_updateemployee", con);
            com_update.Parameters.AddWithValue("@id", id);
            com_update.Parameters.AddWithValue("@city", city);
            com_update.Parameters.AddWithValue("@password", password);
            com_update.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;

            com_update.Parameters.Add(retdata);
            con.Open();
            com_update.ExecuteNonQuery();
            con.Close();
            int count = Convert.ToInt32(retdata.Value);
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }




        }


        public bool Delete(int ID)
        {
            SqlCommand com_delete = new SqlCommand("proc_deleteemployee", con);
            
            com_delete.Parameters.AddWithValue("@id", ID);

            com_delete.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            com_delete.Parameters.Add(retdata);
            con.Open();
             com_delete.ExecuteNonQuery();
            con.Close();
            int count = Convert.ToInt32(retdata.Value);
            
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }



        public List<Employee> ShowEmployees(string city)
        {
            SqlCommand com_employees = new SqlCommand(" proc_showemployees", con);
            com_employees.Parameters.AddWithValue("@city", city);
            com_employees.CommandType = CommandType.StoredProcedure;

            con.Open();
            SqlDataReader dr = com_employees.ExecuteReader();

            List<Employee> emplist = new List<Employee>();

            while (dr.Read())
            {
                Employee obj = new Employee();
                obj.EmployeeID = dr.GetInt32(0);
                obj.EmployeeName = dr.GetString(1);
                obj.EmployeeCity = dr.GetString(2);

                obj.EmployeePassword = dr.GetString(3);
                obj.EmployeeDOJ = dr.GetDateTime(4);
                emplist.Add(obj);
            }
            con.Close();
            return emplist;
        }



        public List<Employee> SearchEmployees(string Search)
        {
            SqlCommand com_search = new SqlCommand("proc_searchemployee", con);
            com_search.Parameters.AddWithValue("@key", Search);
            com_search.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_search.ExecuteReader();
            List<Employee> emplist = new List<Employee>();
            while (dr.Read())
            {
                Employee emp = new Employee();
                emp.EmployeeID = dr.GetInt32(0);
                emp.EmployeeName = dr.GetString(1);
                emp.EmployeeCity = dr.GetString(2);

                emp.EmployeePassword = dr.GetString(3);
                emp.EmployeeDOJ = dr.GetDateTime(4);
                emplist.Add(emp);

            }
            con.Close();
            return emplist;


        }

        public bool Login(int ID, string Password)
        {
            try
            {
                SqlCommand com_login = new SqlCommand("proc_login1", con);
                com_login.Parameters.AddWithValue("@id", ID);
                com_login.Parameters.AddWithValue("@password", Password);
                com_login.CommandType = CommandType.StoredProcedure;
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;

                com_login.Parameters.Add(retdata);
                con.Open();
                com_login.ExecuteNonQuery();
                con.Close();


                int count = Convert.ToInt32(retdata.Value);
                if (count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            finally
            {
                System.Windows.Forms.MessageBox.Show("Finally");
                if(con.State==ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }




        public bool LoginSqlInjection(string ID, string Password)
        {
            SqlCommand com_login = new SqlCommand("select count(*) from tbl_employees where EmployeeID='" + ID + "' and EmployeePassword='" + Password + "'", con);

            con.Open();
            int count = Convert.ToInt32(com_login.ExecuteScalar());
            con.Close();
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

    }
}
 

