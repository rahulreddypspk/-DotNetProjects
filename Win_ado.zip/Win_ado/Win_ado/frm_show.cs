﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_ado
{
    public partial class frm_show : Form
    {
        public frm_show()
        {
            InitializeComponent();
        }

        private void lbl_search_Click(object sender, EventArgs e)
        {
            
        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            EmployeeDAL dal = new EmployeeDAL();
            string city = txt_employeecity.Text;
            List<Employee> list = dal.SearchEmployees(city);
            dg_employee.DataSource = list;

        }

        private void btn_searchall_Click(object sender, EventArgs e)
        {
            EmployeeDAL dal = new EmployeeDAL();
            string key = txt_search.Text;
            List<Employee> list = dal.SearchEmployees(key);
            dg_employee.DataSource = list;
        }

        private void dg_employee_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
