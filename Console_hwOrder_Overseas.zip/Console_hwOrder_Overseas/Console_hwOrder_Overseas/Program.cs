﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_hw_Order_Overseas
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter customer name:");
            string Name = Console.ReadLine();

            Console.WriteLine("enter item name:");
            string ItemName = Console.ReadLine();

            Console.WriteLine("enter item quantity:");
            int ItemQuantity = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("enter Item Price:");
            int ItemPrice = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("enter the type:");
            string type = Console.ReadLine();

            Order obj = null;

            if (type == "Order")

            {
                 obj = new Order(Name, ItemName, ItemQuantity, ItemPrice);
            } 

            else if(type=="Order_Overseas")
           {
                obj = new Order_Overseas(Name, ItemName, ItemQuantity, ItemPrice);

            }
            if (obj!= null)
            {
                int Amt = obj.GetOrderValue();
                Console.WriteLine("amount to be paid is :" + Amt);
            }
            Console.ReadLine();
        }
    }
}
