﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_hw_Order_Overseas
{
    class Order
    {
        private int OrderID;
            private string CustomerName;
            private string ItemName;
            private int ItemQuantity;
            private int ItemPrice;

        private static int count = 100;
        public Order(string CustomerName,string ItemName,int ItemQuantity,int ItemPrice)
        {
            Order.count++;
            this.OrderID = Order.count;
            this.CustomerName = CustomerName;
            this.ItemName = ItemName;
            this.ItemQuantity = ItemQuantity;
            this.ItemPrice = ItemPrice;
        }

        public int POrderID {  get { return this.OrderID; } }

        public string PCustomerName {  get { return this.CustomerName; } }

        public string PItemName {  get { return this.ItemName; } }

        public int PItemQuantity {  get { return this.ItemQuantity; } }

        public int PItemPrice {  get { return this.ItemPrice; } }

        public virtual int GetOrderValue()
        {
            return ItemPrice*ItemQuantity;
        }


    }
}
