﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_hw_Order_Overseas
{
    class Order_Overseas : Order
    {
        public Order_Overseas(string CustomerName, string ItemName, int ItemQuantity, int ItemPrice)
            : base(CustomerName, ItemName, ItemQuantity, ItemPrice)
        {

        }
        public override int GetOrderValue()
        {
        return PItemPrice * PItemQuantity*2;
        }

    }
}