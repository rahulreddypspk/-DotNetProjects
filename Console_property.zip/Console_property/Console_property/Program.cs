﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_property
{
    class program 
    {
        static void Main(string[] args)
        {
        Console.WriteLine("enter student name:");
        string name = Console.ReadLine();
        Console.WriteLine("enter student marks:");
        int marks = Convert.ToInt32(Console.ReadLine());

        student obj = new student(name, marks); 
        int sid = obj.PStudentID;
        string sname = obj.PStudentName;
            int smarks = obj.PStudentMarks;
            student s1 = new student("ABC", 90);
            Console.WriteLine(s1.PStudentID);
        Console.WriteLine(sid + " " + sname + " " +smarks);
            obj.PStudentMarks = 60;
            Console.WriteLine(obj.PStudentMarks);

            obj.PStudentMarks = 90;
            Console.WriteLine(obj.PStudentMarks);

        Console.ReadLine();

        }
    }
}
