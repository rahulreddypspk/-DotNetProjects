﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Console_property
{
    class student
    {
        private int StudentID;
        private string StudentName;
        private int StudentMarks;
        
        public int PStudentID
        {
            get
            {
                return this.StudentID;
            }
        }
        public int PStudentMarks
        {
            get
            {
                return this.StudentMarks;
            }

            set
            {
                if(value<0 || value>100)
                {
                    this.StudentMarks = 0;
                }
                else
                {
                     this.StudentMarks = value;
                }
            }

        }
        public string PStudentName
        {
            get
            {
                return this.StudentName;
            }
        }
        private static int count = 1000;
        public student(string StudentName,int StudentMarks)
        {
            student.count++;
            this.StudentID = student.count;
            this.StudentName = StudentName;
            this.StudentMarks = StudentMarks;
        }
        static student()
        {
            student.count = 1000;
            Console.WriteLine("static constructor");
        }
    }
}
