﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Attributes
{
    [AttributeUsage(AttributeTargets.Class|AttributeTargets.Method)]
    class DevloperAttribute: Attribute
    {
        public string DevloperID { get; set; }
        public string DevloperName { get; set; }
        public DevloperAttribute(string DevloperID,string DevloperName)
        {
            this.DevloperID = DevloperID;
            this.DevloperName = DevloperName;
        }
    }
}
