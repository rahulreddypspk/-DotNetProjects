﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace Console_Attributes
{
    class Program
    {
        static void Main(string[] args)
        {
           // Test obj = new Test();
            //obj.call();
           
            Type t = typeof(Test);

          DevloperAttribute att=  Attribute.GetCustomAttribute(t, typeof(DevloperAttribute)) as DevloperAttribute;

            Console.WriteLine(att.DevloperID + " " + att.DevloperName);

            foreach(MethodInfo m in t.GetMethods() )
            {
                DevloperAttribute attmethod = Attribute.GetCustomAttribute(t, typeof(DevloperAttribute)) as DevloperAttribute;
                if(attmethod!=null)
                {
                    Console.WriteLine(m.Name + " " + attmethod.DevloperID + " " + attmethod.DevloperName);
                }
            }
            Console.ReadLine();
        }
    }
}
