﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Win_ThreadPool
{
    public partial class Form1 : Form
    {
        public void call(object obj)
        {
            int id = Thread.CurrentThread.ManagedThreadId;
            MessageBox.Show("thread id" + id + " loop no" + obj);
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_threadpool_Click(object sender, EventArgs e)
        {
            ThreadPool.SetMaxThreads(10, 1000);
            ThreadPool.SetMinThreads(5, 1000);

            int counter = 0;
            while(counter<20)
            {
                ThreadPool.QueueUserWorkItem(call, counter);
                counter++;
            }
            MessageBox.Show("main Thread");
        }
    }
}
