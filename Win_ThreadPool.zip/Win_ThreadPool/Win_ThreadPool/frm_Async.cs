﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Win_ThreadPool
{
    public partial class frm_Async : Form
    {
        public delegate int delthread(int n1, int n2);

        public int getsum(int n1,int n2)
        {
            Thread.Sleep(4000);
            return n1 + n2;
        }


        public delegate void del();
        public void callback(IAsyncResult res)
        {

            int returndata = d.EndInvoke(res);
            // MessageBox.Show("get sum called" +res.AsyncState + " : " + returndata);

            del obj = new del(() =>
              {
                  lst_msg.Items.Add(res.AsyncState + " : " + returndata);

              });
            this.BeginInvoke(obj);

            }

        public frm_Async()
        {
            InitializeComponent();
        }
        delthread d;
        private void btn_thread_Click(object sender, EventArgs e)
        {
            if(d==null)

            {
                d= new delthread(this.getsum);

            }
            int n1 = Convert.ToInt32(txt_number1.Text);

            int n2 = Convert.ToInt32(txt_number2.Text);

            string str = n1 + " + " + n2;//10+10
                d.BeginInvoke(n1, n2, callback, str);//new thread
            //d.BeginInvoke(n1, n2, callback, "1002");
        }
    }
}
