﻿namespace Win_ThreadPool
{
    partial class frm_Async
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_number1 = new System.Windows.Forms.Label();
            this.lbl_number2 = new System.Windows.Forms.Label();
            this.txt_number1 = new System.Windows.Forms.TextBox();
            this.txt_number2 = new System.Windows.Forms.TextBox();
            this.btn_asyncsum = new System.Windows.Forms.Button();
            this.lst_msg = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // lbl_number1
            // 
            this.lbl_number1.AutoSize = true;
            this.lbl_number1.Location = new System.Drawing.Point(56, 48);
            this.lbl_number1.Name = "lbl_number1";
            this.lbl_number1.Size = new System.Drawing.Size(68, 17);
            this.lbl_number1.TabIndex = 0;
            this.lbl_number1.Text = "number1:";
            // 
            // lbl_number2
            // 
            this.lbl_number2.AutoSize = true;
            this.lbl_number2.Location = new System.Drawing.Point(56, 93);
            this.lbl_number2.Name = "lbl_number2";
            this.lbl_number2.Size = new System.Drawing.Size(68, 17);
            this.lbl_number2.TabIndex = 1;
            this.lbl_number2.Text = "number2:";
            // 
            // txt_number1
            // 
            this.txt_number1.Location = new System.Drawing.Point(134, 49);
            this.txt_number1.Name = "txt_number1";
            this.txt_number1.Size = new System.Drawing.Size(100, 22);
            this.txt_number1.TabIndex = 2;
            // 
            // txt_number2
            // 
            this.txt_number2.Location = new System.Drawing.Point(134, 97);
            this.txt_number2.Name = "txt_number2";
            this.txt_number2.Size = new System.Drawing.Size(100, 22);
            this.txt_number2.TabIndex = 3;
            // 
            // btn_asyncsum
            // 
            this.btn_asyncsum.Location = new System.Drawing.Point(124, 221);
            this.btn_asyncsum.Name = "btn_asyncsum";
            this.btn_asyncsum.Size = new System.Drawing.Size(165, 54);
            this.btn_asyncsum.TabIndex = 4;
            this.btn_asyncsum.Text = "Async sum";
            this.btn_asyncsum.UseVisualStyleBackColor = true;
            this.btn_asyncsum.Click += new System.EventHandler(this.btn_thread_Click);
            // 
            // lst_msg
            // 
            this.lst_msg.FormattingEnabled = true;
            this.lst_msg.ItemHeight = 16;
            this.lst_msg.Location = new System.Drawing.Point(451, 207);
            this.lst_msg.Name = "lst_msg";
            this.lst_msg.Size = new System.Drawing.Size(120, 84);
            this.lst_msg.TabIndex = 5;
            // 
            // frm_Async
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(883, 403);
            this.Controls.Add(this.lst_msg);
            this.Controls.Add(this.btn_asyncsum);
            this.Controls.Add(this.txt_number2);
            this.Controls.Add(this.txt_number1);
            this.Controls.Add(this.lbl_number2);
            this.Controls.Add(this.lbl_number1);
            this.Name = "frm_Async";
            this.Text = "frm_Async";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_number1;
        private System.Windows.Forms.Label lbl_number2;
        private System.Windows.Forms.TextBox txt_number1;
        private System.Windows.Forms.TextBox txt_number2;
        private System.Windows.Forms.Button btn_asyncsum;
        private System.Windows.Forms.ListBox lst_msg;
    }
}