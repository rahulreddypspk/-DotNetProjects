﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_Refelection
{
    class Test
    {
        public void call1() { }
        public void call2() { }
    }

}
