﻿namespace Win_Refelection
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_readtype = new System.Windows.Forms.Button();
            this.btn_loadassembly = new System.Windows.Forms.Button();
            this.lst_classes = new System.Windows.Forms.ListBox();
            this.lst_methods = new System.Windows.Forms.ListBox();
            this.btn_call = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_readtype
            // 
            this.btn_readtype.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_readtype.Location = new System.Drawing.Point(89, 41);
            this.btn_readtype.Name = "btn_readtype";
            this.btn_readtype.Size = new System.Drawing.Size(232, 76);
            this.btn_readtype.TabIndex = 0;
            this.btn_readtype.Text = "Read Type";
            this.btn_readtype.UseVisualStyleBackColor = true;
            this.btn_readtype.Click += new System.EventHandler(this.btn_readtype_Click);
            // 
            // btn_loadassembly
            // 
            this.btn_loadassembly.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_loadassembly.Location = new System.Drawing.Point(89, 149);
            this.btn_loadassembly.Name = "btn_loadassembly";
            this.btn_loadassembly.Size = new System.Drawing.Size(232, 76);
            this.btn_loadassembly.TabIndex = 1;
            this.btn_loadassembly.Text = "Load Assembly";
            this.btn_loadassembly.UseVisualStyleBackColor = true;
            this.btn_loadassembly.Click += new System.EventHandler(this.btn_loadassembly_Click);
            // 
            // lst_classes
            // 
            this.lst_classes.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lst_classes.FormattingEnabled = true;
            this.lst_classes.ItemHeight = 20;
            this.lst_classes.Location = new System.Drawing.Point(2, 263);
            this.lst_classes.Name = "lst_classes";
            this.lst_classes.Size = new System.Drawing.Size(246, 204);
            this.lst_classes.TabIndex = 2;
            this.lst_classes.SelectedIndexChanged += new System.EventHandler(this.lst_classes_SelectedIndexChanged);
            // 
            // lst_methods
            // 
            this.lst_methods.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lst_methods.FormattingEnabled = true;
            this.lst_methods.ItemHeight = 20;
            this.lst_methods.Location = new System.Drawing.Point(293, 263);
            this.lst_methods.Name = "lst_methods";
            this.lst_methods.Size = new System.Drawing.Size(246, 204);
            this.lst_methods.TabIndex = 3;
            // 
            // btn_call
            // 
            this.btn_call.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_call.Location = new System.Drawing.Point(653, 375);
            this.btn_call.Name = "btn_call";
            this.btn_call.Size = new System.Drawing.Size(232, 76);
            this.btn_call.TabIndex = 4;
            this.btn_call.Text = "CALL";
            this.btn_call.UseVisualStyleBackColor = true;
            this.btn_call.Click += new System.EventHandler(this.btn_call_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(964, 487);
            this.Controls.Add(this.btn_call);
            this.Controls.Add(this.lst_methods);
            this.Controls.Add(this.lst_classes);
            this.Controls.Add(this.btn_loadassembly);
            this.Controls.Add(this.btn_readtype);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_readtype;
        private System.Windows.Forms.Button btn_loadassembly;
        private System.Windows.Forms.ListBox lst_classes;
        private System.Windows.Forms.ListBox lst_methods;
        private System.Windows.Forms.Button btn_call;
    }
}

