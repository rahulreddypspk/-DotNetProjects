﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_order_assig2
{
    class Program
    {
        static void Main(string[] args)
        { 
            Console.WriteLine("enter the Order Id:");
            int id = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("enter the customer name:");
            string custname = Console.ReadLine();
        Console.WriteLine("enter the item name:");
            string itemname = Console.ReadLine();
        Console.WriteLine("enter the item price:");
            int itemprice=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter the quantity:");
            int itemqty = Convert.ToInt32(Console.ReadLine());

            order obj = new order(id, custname, itemname, itemprice,itemqty);
            int Amt=obj.GetOrderAmount();
        Console.WriteLine("amount to be paid is:" +Amt);
            string details = obj.GetDetails();
        Console.WriteLine(details);
            Console.ReadLine();
        }
    }
}
