﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_order_assig2
{
    class order
    {
        private int OrderID;
        private string CustomerName;
        private string ItemName;
        private int ItemPrice;
        private int ItemQuantity;

        public order(int OrderID, string CustomerName, string ItemName, int ItemPrice, int ItemQuantity)
        {
            this.OrderID = OrderID;
            this.CustomerName = CustomerName;
            this.ItemName = ItemName;
            this.ItemPrice = ItemPrice;
            this.ItemQuantity = ItemQuantity;
        }
        public int GetOrderAmount()
        {
           return ItemPrice * ItemQuantity;
        }
        public string GetDetails()
        {
            return OrderID + " " + CustomerName + " " + ItemName + " " + ItemPrice + " " + ItemQuantity;
        }
            
        }
    }
