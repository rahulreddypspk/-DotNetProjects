﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP_Overriding
{
   static class EXTMETHODS
    {
        public static void NewEmployeeMethods( this Employee e,string str)
        {
            Console.WriteLine("this is Extension Methods:" + str);
        }
    }
}
