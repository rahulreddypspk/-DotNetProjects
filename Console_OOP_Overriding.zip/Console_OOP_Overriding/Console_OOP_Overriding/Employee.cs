﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP_Overriding
{
    class Employee
    {
        private int EmployeeID;
        private string EmployeeName;
        private int EmployeeSalary;
        

        public Employee(int EmployeeID,string EmployeeName,int EmployeeSalary)
        {
            this.EmployeeID = EmployeeID;
            this.EmployeeName = EmployeeName;
            this.EmployeeSalary = EmployeeSalary;

        }
        public int PEmployeeID
        {
            get
            {
                return EmployeeID;

            }
        }
        public string PEmployeeName
        {
            get
            {
                return EmployeeName;
            }
        }
        public int PEmployeeSalary
        {
            get
            {
                return EmployeeSalary;
            }
        }
        public string GetWork()
        {
            return "Developing .net Aplication";
        }
        public virtual int GetSalary(int Days)
        {
            int Bonus = 2000;
            int TDS = 1000;
            int Salary = (this.EmployeeSalary / 30 * Days) + Bonus-TDS;
            return Salary;
        }
    }
}
