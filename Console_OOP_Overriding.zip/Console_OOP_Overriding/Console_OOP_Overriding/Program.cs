﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP_Overriding
{
    class Program
    {
        static void Main(string[] args)

        {
            Console.WriteLine("enter Employee ID:");
            int ID = Convert.ToInt32(Console.ReadLine());
         Console.WriteLine("enter Employee Name:");
            string Name = Console.ReadLine();
            Console.WriteLine("enter Employee Salary:");
            int Salary = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("enter type of Employee:");
            string type = Console.ReadLine();

            Employee obj = null;
            if(type=="Employee")
            {
                obj = new Employee(ID, Name, Salary);
            }
            else if(type=="Contract")
            {
                obj = new Employee_Contract(ID, Name, Salary);
            }
            else if(type=="Employee_training")
            {
                obj = new Employee_training(ID, Name, Salary);
            }

            if (obj != null)
            {

                string Work = obj.GetWork();
                
                Console.WriteLine(Work);

                Console.WriteLine("enter days:");
                int Days = Convert.ToInt32(Console.ReadLine());
                int CurrentMonthSalary = obj.GetSalary(Days);
                Console.WriteLine("Salary :" + CurrentMonthSalary);
            }
            Console.ReadLine();
            


        }
    }
}
