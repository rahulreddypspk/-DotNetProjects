create table tbl_accounts
(
AccountID int identity(1000,1),
CustomerName varchar(100),
AccountBalance int
)

insert tbl_accounts values('john',3000)
insert tbl_accounts values('rahul',4000)
insert tbl_accounts values('reddy',5000)
insert tbl_accounts values('kanak',6000)
insert tbl_accounts values('sai',7000)

 
delete tbl_accounts where CustomerName='john'

select @@identity