create database BANKDB1

create table Customerinfo
(
CustomerID int identity(101,1) primary key,
CustomerName varchar(100) not null,
CustomerCity varchar(100) not null,
CustomerAddress varchar(100) not null,
customerMoblieNO varchar(20) unique,
customerPAN varchar(100) unique,
CustomerPassword varchar(100) unique
)

insert Customerinfo values('RamReddy','HYD','UPPAL','7702404567','1020','9999')

select * from Customerinfo

create table Accountinfo
(
AccountID int identity(1001,1) primary key,
CustomerID int not null foreign key references Customerinfo(CustomerID),
AccountType varchar(100) not null,
AccountBalance int not null,
AccountOpenDate datetime not null,
AccountStatus varchar(100) not null
)

insert Accountinfo values(112,'Credit',90000,getdate(),'open')

select * from Accountinfo

update Accountinfo set AccountType='Current' where AccountType='Credit'
create table TransactionInfo
(
TransactionID int identity(20001,1) primary key,
AccountID int not null foreign key references AccountINFO(AccountID),
TransactionType varchar(100) not null,
Amount int check(Amount>0),
TransactionDate datetime not null
)

insert TransactionInfo values(1010,'CRIDET',100000,'08-12-2018')

select * from TransactionInfo

--1
select top 5 * from transactioninfo where accountID=1001 order by transactionDate desc

--2
select * from TransactionInfo  where  transactionDate between '11-01-2018' and '12-12-2018'

--3
select * from Accountinfo where CustomerID=102
--4
select c.CustomerID,c.CustomerName,c.CustomerAddress,c.CustomerMoblieNO,
a.AccountID,a.AccountBalance from Customerinfo c join Accountinfo a
on
c.CustomerID=a.CustomerID
--5
select a.AccountID,a.AccountBalance,t.transactionID,t.amount,t.transactionType 
from Accountinfo a join TransactionInfo t
on
a.AccountID=t.AccountID
--6
select c.CustomerID,c.CustomerName,c.CustomerAddress,c.CustomerMoblieNO,
a.AccountID,a.AccountBalance,t.transactionID,t.Amount,t.TransactionType 
from Customerinfo c join Accountinfo a
on 
c.CustomerID=a.CustomerID 
join 
TransactionInfo t 
on 
a.AccountID=t.AccountID
--7
select * from Customerinfo where CustomerID in(select CustomerID  from Accountinfo)
--8

select * from Customerinfo where CustomerID not in(select CustomerID  from Accountinfo)

--9
select * from Accountinfo where AccountID in(select AccountID from TransactionInfo)

--10
select * from Accountinfo where AccountID not in(select AccountID from TransactionInfo)