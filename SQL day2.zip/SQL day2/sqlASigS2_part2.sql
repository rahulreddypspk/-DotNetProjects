create database onlinefoodorderingdb1

use onlinefoodorderingdb1

create table Restaurents
(
RestaurentID int identity(1001,1) primary key,
RestaurentName varchar(100) not null,
RestaurentAddress varchar(100) not null,
RestaurentCity varchar(100)  not null,
ConactNO varchar(100) not null
)

insert Restaurents values('Bhawarchi','Kothapet','PUNE','7702401235')

select * from Restaurents

create table RMenuItems
(
MenuID int identity(1,1) primary key,
RestaurentID int not null foreign key references Restaurents(RestaurentID),
MenuName varchar(100) not null,
MenuType varchar(100) not null,
Menucatagory varchar(100) not null,
MenuPrice int not null,
MenuDesc varchar(100)
)

insert RMenuItems values(1005,'abc3','non-veg','Thai',300,'add Sause')

select * from RMenuItems

create table Customers
(
CustomerID varchar(100) primary key,
CustomerName varchar(100) not null,
CustomerCity varchar(100) not null,
CustomerDOB datetime not null,
CustomerGender varchar(100) not null,
CustomerPassword varchar(100) not null
)

insert Customers values('xyz@gamail.com','laxshmi','thumkur','11-20-1994','Female','xyz5')

select * from Customers

create table Orders
(
OrderID int identity(20001,1) primary key,
CustomerID varchar(100) not null foreign key references Customers(CustomerID),
orderDAte datetime not null,
DeliveryAddress varchar(100) not null,
OrderStatus varchar(100) not null
)

insert Orders values('xyz@gamail.com','08-08-2018','jp nagar','not Delivered')

select * from Orders

create table OrderMenu
(
OrderID int not null foreign key references orders(OrderID),
MenuID int not null foreign key references RmenuItems(MenuID),
MenuQty int not null,
MenuPrice int not null,
primary key(OrderID,MenuID)
)


insert OrderMenu values(20005,4,4,500

select * from OrderMenu

--1
select * from Restaurents where RestaurentCity='HYD'

--2
select r.restaurentID,r.restaurentName,m.menuID,m.menuName,m.menuPrice
from Restaurents r join RMenuItems m 
on
r.RestaurentID=m.RestaurentID

--3
select r.restaurentID,r.restaurentName,r.RestaurentCity,m.menuID,m.menuName,m.menuPrice
from Restaurents r join RMenuItems m 
on
r.RestaurentID=m.RestaurentID 
where RestaurentCity='HYD'

--4
select * from Orders where CustomerID='rahulreddy@gamail.com'

--5
select * from Orders
select * from OrderMenu

select o.ORDERid,o.CustomerID,o.Orderdate,m.MenuID,m.MenuQTY,m.MenuPrice
from Orders o  join OrderMenu m 
on
o.OrderID=m.OrderID

--6
--Show the list of latest 5 orders of a specific customer (based on CustomerID)

select top 5 OrderId,CustomerID ,Orderdate from Orders where CustomerID='rahulreddy@gamail.com'
order by orderdate desc

--7
select * from OrderMenu  order by MenuPrice asc

--8
select REstaurentCity,count(RestaurentName) as 'NO of REStaurents' from Restaurents 
group by RestaurentCity

--9
select * from Customers where CustomerID not in(select CustomerID from orders)

--10
select top 1 * from RMenuItems order by MenuPrice desc

--11

select top 1 * from RmenuItems where menuprice not in
(select top 1 menuprice from RMenuItems order by MenuPrice desc)

