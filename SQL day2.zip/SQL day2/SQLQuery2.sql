create database pathfrontDB2

use pathfrontdb2

create table tbl_Customers
(
CustomerID int identity(1000,1) primary key,
CustomerName varchar(100) not null,
CustomerCity varchar(100) not null,
CustomerEmail varchar(100) not null unique,
CustomerMobileNO varchar(15) not null unique
)

insert tbl_Customers values('rahul','HYD','rahulreddypspk@gamil.com','7702409796')
insert tbl_Customers values('reddy','HYD','rahul25@gmail.com','9989120234')
insert tbl_Customers values('sai','GOA','saiprabath@gmail.com','9490091150')
insert tbl_Customers values('kanak','GOA','kanakasai@gmail.com','8686009612')
insert tbl_Customers values('manish','GUNTUR','manish@gmail.com','9849332196')



SELECT * FROM tbl_Customers



create table tbl_Items
(
ItemID int identity(1,1) primary key,
ItemName varchar(100) not null,
ItemPrice int check(ItemPrice>0)
)

insert tbl_Items values('pendrive',1000)
insert tbl_Items values('harddisk',2000)
insert tbl_Items values('cooker',3000)
insert tbl_Items values('cooler',4000)
insert tbl_Items values('mobile',5000)


select * from tbl_Items

create table tbl_Invoices
(
InvoiceID int identity(10000,1) primary key,
CustomerID int not null foreign key references tbl_Customers(CustomerID),
InvoiceCity varchar(100) not null,
InvoiceDate datetime not null,
InvoiceAddress varchar(100)
)

insert tbl_Invoices values( 1000,'HYD','08-08-2008','LB nagar')
insert tbl_Invoices values(1001,'PUNE','09-09-2009','JP nagar')
insert tbl_Invoices values(1002,'BANGALORE','10-10-2010','OMKAR nagar')
insert tbl_Invoices values(1003,'KOLKATHA','11-11-2011','BN reddy')
insert tbl_Invoices values(1004,'KERLA','12-12-2012','SAGAR road')

select * from tbl_Invoices

select * from tbl_Customers where CustomerID in(
select CustomerID from tbl_Invoices)

select * from tbl_Customers where CustomerID not in (
select CustomerID from tbl_Invoices)


select * from tbl_Items where itemID in(select itemID from tbl_InvoiceItems)


select * from tbl_Customers where CustomerID in(
 select top 1 CustomerID from tbl_Invoices order by InvoiceDate desc)



create table tbl_InvoiceItems
(
InvoiceID int not null foreign key references tbl_Invoices(invoiceID),
ItemID int not null foreign key references tbl_Items(itemID),
ItemQty int check(itemQty>0),
ItemPrice int check(ItemPrice>0),
primary key(invoiceid,itemid)
)
 
 insert tbl_InvoiceItems values(10000,1,2,100)

 insert tbl_InvoiceItems values(10001,3,3,200)

 insert tbl_InvoiceItems values(10003,4,4,500)

 insert tbl_InvoiceItems values(10003,1,1,100)

 insert tbl_InvoiceItems values(10004,1,2,20)

 insert tbl_InvoiceItems values(10000,2,1,1000)
 
 insert tbl_InvoiceItems values(10003,2,20,40)
 update tbl_InvoiceItems set ItemQty=3 where InvoiceID=10000 and ItemID=1

 select * from tbl_InvoiceItems



 create  table tbl_Employees
 (
 EmployeeID int identity(1,1) primary key,
 EmployeeName varchar(100) not null,
 EmployeeSalary int not null,
 EmployeeDEPT varchar(100),
 ManagerID int foreign key references tbl_employees(EmployeeID)
 )

 insert tbl_Employees values('john',20000,'HR',null)
 insert tbl_Employees values('rosy',16000,'HR',1)
 insert tbl_Employees values('XYZ',20000,'IT',null)
 insert tbl_Employees values('ABC',18000,'It',3)
 insert tbl_Employees values('rahul',50000,'HR',null)
 
 select * from tbl_Employees

 select * from tbl_Employees e1 where e1.EmployeeSalary>
 (select avg(e2.EmployeeSalary) from tbl_Employees e2
 where e2.EmployeeDEPT=e1.EmployeeDEPT)

 select top 1 * from tbl_Employees where EmployeeID in
 (select top 2  EmployeeID from tbl_Employees order by EmployeeSalary desc)
 order by EmployeeSalary asc
 


 select * from tbl_Customers
  select * from tbl_Invoices


  select tbl_Customers.CustomerID,tbl_Customers.CustomerName,tbl_Invoices.InvoiceID,tbl_Invoices.InvoiceDate
  from tbl_Customers join tbl_Invoices
  on
  tbl_Customers.CustomerID=tbl_Invoices.CustomerID


  select * from tbl_Invoices
  select * from tbl_InvoiceItems

  select tbl_Invoices.InvoiceID,tbl_Invoices.CustomerID,tbl_Invoices.InvoiceCity,
  tbl_InvoiceItems.itemID,tbl_InvoiceItems.ItemQty,tbl_Items.ItemName from
  tbl_Invoices  left join tbl_InvoiceItems
  on
  tbl_Invoices.InvoiceID=tbl_InvoiceItems.InvoiceID
  join tbl_Items
  on
  tbl_InvoiceItems.ItemID=tbl_Items.ItemID



  
  select tbl_Invoices.InvoiceID,tbl_Invoices.CustomerID,tbl_Invoices.InvoiceCity,
  tbl_InvoiceItems.itemID,tbl_InvoiceItems.ItemQty from
  tbl_Invoices  full outer join tbl_InvoiceItems
  on
  tbl_Invoices.InvoiceID=tbl_InvoiceItems.InvoiceID
 
 select * from tbl_Customers cross join tbl_Invoices

 select * from tbl_Employees

 select e.EmployeeID,e.EmployeeName,e.EmployeeSalary,e.managerid,m.EmployeeName
 from tbl_Employees e left  outer join tbl_Employees m
 on
 e.ManagerID=m.EmployeeID