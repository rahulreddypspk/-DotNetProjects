﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_LINQ
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Customer> custlist = new List<Customer>();
            custlist.Add(new Customer { CustomerID = 1, CustomerName = "rahul", CustomerAge = 25, CustomerCity = "BGL" });

            custlist.Add(new Customer { CustomerID = 1, CustomerName = "reddy", CustomerAge = 20, CustomerCity = "hyd" });

            custlist.Add(new Customer { CustomerID = 3, CustomerName = "sai", CustomerCity = "goa", CustomerAge = 21 });


            custlist. Add(new Customer { CustomerID = 4, CustomerName = "kanak", CustomerCity = "bgn", CustomerAge = 22 });

            custlist.Add(new Customer { CustomerID = 5, CustomerName = "manish", CustomerCity = "goa", CustomerAge = 23 });

            List<Order> ordlist = new List<Order>();

            ordlist.Add(new Order { OrderID = 1001, CustomerID = 1, ItemName = "onePLus", ItemPrice = 10000 });

            ordlist.Add(new Order { OrderID = 1002, CustomerID = 2, ItemName = "Tv", ItemPrice = 20000 });

            ordlist.Add(new Order { OrderID = 1003, CustomerID = 3, ItemName = "fridge", ItemPrice = 30000 });

            ordlist.Add(new Order { OrderID = 1004, CustomerID = 4, ItemName = "ac", ItemPrice = 40000 });


            
            string city = "goa";
            var q = from c in custlist
                    where c.CustomerCity == city
                    orderby c.CustomerAge descending,c.CustomerName ascending
                    select c;

            foreach(var x in q)
            {
                Console.WriteLine(x.CustomerID + " " + x.CustomerName + " " + x.CustomerCity);

            }


            var count = (from c in custlist
                         where c.CustomerCity == city
                         select c).Count();

            Console.WriteLine(count);


            var obj = (from c in custlist
                       where c.CustomerID == 1
                       select c).FirstOrDefault();

            if(obj!=null)
            {
                Console.WriteLine(obj.CustomerID + " " + obj.CustomerName);
            }
            else
            {
                Console.WriteLine("not found");
            }


            var qdata = from c in custlist
                         where c.CustomerAge > 20
                         select new { CID = c.CustomerID, CName = c.CustomerName, CCity = c.CustomerCity };

            foreach(var p in qdata)
            {
                Console.WriteLine(p.CID + " " + p.CName + " " + p.CCity);


            }

            var joindata = from c in custlist
                           join
                           o in ordlist
                           on c.CustomerID equals o.CustomerID
                           select new { CID = c.CustomerID, CName = c.CustomerName, OID = o.OrderID, ItemName = o.ItemName, Price = o.ItemPrice };

            foreach(var j in joindata)
            {
                Console.WriteLine(j.CID + " " + j.CName + " " + j.OID + " " + j.ItemName + " " + j.Price);
            }

            Console.ReadLine();
        }
    }
}
