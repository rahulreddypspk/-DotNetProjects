﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_orderProperty
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter customer name:");
            string custname = Console.ReadLine();
            Console.WriteLine("enter item name:");
                string itemname = Console.ReadLine();
            Console.WriteLine("enter item price:");
            int itemprice = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter item quantity:");
            int itemqty = Convert.ToInt32(Console.ReadLine());

            Order obj = new Order(custname,itemname,itemprice,itemqty);
            int Oid = obj.POrderID;
            Console.WriteLine("Oid" + Oid);
            string name = obj.PCustomerName;
            string itemN = obj.PItemName;
            int amt=obj.OrderAmount();
            Console.WriteLine("order amount is :" + amt);

          
                string details = obj.GetDetails();
            Console.WriteLine(details);
            Console.ReadLine();


        }
    }
}
