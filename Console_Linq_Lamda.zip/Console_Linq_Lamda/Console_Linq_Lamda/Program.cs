﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Linq_Lamda
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Employees> emplist = new List<Employees>();

            emplist.Add(new Employees { EmployeeID = 1001, EmployeeName = "rahul", EmployeeSalary = 70000, EmployeeExperience = 2, EmployeeCity = "HYD" });

            emplist.Add(new Employees { EmployeeID = 1002, EmployeeName = "Reddy", EmployeeSalary = 50000, EmployeeExperience = 3, EmployeeCity = "GOA" });

            emplist.Add(new Employees { EmployeeID = 1003, EmployeeName = "kanak", EmployeeSalary = 10000, EmployeeExperience = 3, EmployeeCity = "BGL" });
            emplist.Add(new Employees { EmployeeID = 1004, EmployeeName = "sai", EmployeeSalary = 30000, EmployeeExperience = 2, EmployeeCity = "HYD" });
            emplist.Add(new Employees { EmployeeID = 1005, EmployeeName = "Revanth", EmployeeSalary = 40000, EmployeeExperience = 6, EmployeeCity = "GOA" });


            List<EmployeeLeave> levlist = new List<EmployeeLeave>();

            levlist.Add(new EmployeeLeave { LeaveID = 1, LeaveType = "sick", Reason = "not well", EmployeeID = 1001 });

            levlist.Add(new EmployeeLeave { LeaveID = 2, LeaveType = "weekend", Reason = "party", EmployeeID = 1002 });
            
            levlist.Add(new EmployeeLeave { LeaveID = 3, LeaveType = "timepass", Reason = "cricket", EmployeeID = 1003 });


            levlist.Add(new EmployeeLeave { LeaveID = 4, LeaveType = "timepass", Reason = "football", EmployeeID = 1004 });
            levlist.Add(new EmployeeLeave { LeaveID = 5, LeaveType = "sick", Reason = "headache", EmployeeID = 1005});

            //1 linq
            var q = from c in emplist
                    where c.EmployeeExperience > 5
                    select c;
            foreach(var x in q)
            {
                Console.WriteLine(x.EmployeeID + " " + x.EmployeeName + " " + x.EmployeeSalary + " " + x.EmployeeExperience + " " + x.EmployeeCity);
            }

            //1 lamda
            var data = emplist.Where((c) => c.EmployeeExperience > 5);

            foreach (var x in data)
            {
                Console.WriteLine(x.EmployeeID + " " + x.EmployeeName + " " + x.EmployeeSalary + " " + x.EmployeeExperience + " " + x.EmployeeCity);
            }


            //2 linq
            var s = from c in emplist
                    where c.EmployeeSalary > 50000
                    select c;

            foreach (var x in s)
            {
                Console.WriteLine(x.EmployeeID + " " + x.EmployeeName + " " + x.EmployeeSalary + " " + x.EmployeeExperience + " " + x.EmployeeCity);
            }


            //2 lamda
            var sl = emplist.Where((m) => m.EmployeeSalary > 50000);

            foreach (var x in sl)
            {
                Console.WriteLine(x.EmployeeID + " " + x.EmployeeName + " " + x.EmployeeSalary + " " + x.EmployeeExperience + " " + x.EmployeeCity);
            }

            //3 linq
            var r = from c in emplist
                    where c.EmployeeCity=="GOA"
                    select c;

            foreach (var x in r)
            {
                Console.WriteLine(x.EmployeeID + " " + x.EmployeeName + " " + x.EmployeeSalary + " " + x.EmployeeExperience + " " + x.EmployeeCity);
            }

            //3 lamda
            var ct = emplist.Where((city) => city.EmployeeCity == "GOA");

            foreach (var x in ct)

            {
                Console.WriteLine(x.EmployeeID + " " + x.EmployeeName + " " + x.EmployeeSalary + " " + x.EmployeeExperience + " " + x.EmployeeCity);
            }

            //4
            var n = from c in emplist
                    where c.EmployeeName.StartsWith("r")
                    select c;

            foreach (var x in n)

            {
                Console.WriteLine(x.EmployeeID + " " + x.EmployeeName + " " + x.EmployeeSalary + " " + x.EmployeeExperience + " " + x.EmployeeCity);
            }

            //4 lamda
            var na = emplist.Where((name) => name.EmployeeName.StartsWith("r"));

            foreach (var x in na)
            {
                Console.WriteLine(x.EmployeeID + " " + x.EmployeeName + " " + x.EmployeeSalary + " " + x.EmployeeExperience + " " + x.EmployeeCity);

            }

            //5 linq
            var joindata = from c in emplist
                           join
                           l in levlist
                           on c.EmployeeID equals l.EmployeeID
                           select new { EID = c.EmployeeID, EName = c.EmployeeName, ECity = c.EmployeeCity, LeaveID = l.LeaveID, LeaveType = l.LeaveType, Reason = l.Reason };

            foreach(var j in joindata)
            {
                Console.WriteLine(j.EID + " " + j.EName + " " + j.ECity + " " + j.LeaveID + " " + j.LeaveType + " " + j.Reason);
            }

            //5 lamda
            var jn= emplist.Join(levlist,
                (c) => c.EmployeeID,
                (l) => l.EmployeeID,
                (c, l) => new
                { EID = c.EmployeeID,
                    EName = c.EmployeeName,
                    ECity = c.EmployeeCity,
                    LeaveID = l.LeaveID,
                    LeaveType = l.LeaveType,
                    Reason = l.Reason });

            foreach (var j in jn)
            {
                Console.WriteLine(j.EID + " " + j.EName + " " + j.ECity + " " + j.LeaveID + " " + j.LeaveType + " " + j.Reason);
            }

            Console.ReadLine();

        }
    }
}
