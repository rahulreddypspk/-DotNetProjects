﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace Win_students
{
    class StudentDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["stu"].ConnectionString);

        public int AddStudent(Student obj)
        {
                 try { 

                SqlCommand stu_insert = new SqlCommand("add_student", con);
                stu_insert.Parameters.AddWithValue("@name", obj.StudentName);
                stu_insert.Parameters.AddWithValue("@city", obj.StudentCity);
                stu_insert.Parameters.AddWithValue("@address", obj.StudentAddress);
                stu_insert.Parameters.AddWithValue("@emailid", obj.StudentEmailID);
                stu_insert.Parameters.AddWithValue("@password", obj.StudentPassword);
            
                stu_insert.CommandType = CommandType.StoredProcedure;
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;

                stu_insert.Parameters.Add(retdata);

                con.Open();
                stu_insert.ExecuteNonQuery();

                con.Close();

                int id = Convert.ToInt32(retdata.Value);

                return id;
            }
            finally
            {
                System.Windows.Forms.MessageBox.Show("Finally");
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            

        }
        public Student Find(int id)
        {
            try
            {
                SqlCommand stu_find = new SqlCommand("proc_find_student", con);
                stu_find.Parameters.AddWithValue("@id", id);
                stu_find.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader dr = stu_find.ExecuteReader();
                if (dr.Read())
                {
                    Student stu = new Student();

                    stu.StudentID = dr.GetInt32(0);
                    stu.StudentName = dr.GetString(1);
                    stu.StudentCity = dr.GetString(2);
                    stu.StudentAddress = dr.GetString(3);
                    stu.StudentEmailID = dr.GetString(4);
                    con.Close();

                    return stu;
                }

                else
                {
                    return null;
                }
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        public bool Update(int id, string address)
        {
            SqlCommand stu_update = new SqlCommand("proc_update_student", con);
            stu_update.Parameters.AddWithValue("@id", id);
            stu_update.Parameters.AddWithValue("@address", address);
            stu_update.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            stu_update.Parameters.Add(retdata);

            con.Open();
            stu_update.ExecuteNonQuery();
            con.Close();
            int count = Convert.ToInt32(retdata.Value);

            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool Delete(int id)
        {
            SqlCommand stu_delete = new SqlCommand("proc_delete_student", con);
            stu_delete.Parameters.AddWithValue("@id", id);
            stu_delete.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            stu_delete.Parameters.Add(retdata);
            con.Open();
            stu_delete.ExecuteNonQuery();
            con.Close();
            int count = Convert.ToInt32(retdata.Value);

            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }

        }





        public bool loginid(int id, string password)
        {
            SqlCommand login_student = new SqlCommand("proc_loginid", con);
            login_student.Parameters.AddWithValue("@id", id);
            login_student.Parameters.AddWithValue("@password", password);
            login_student.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            login_student.Parameters.Add(retdata);
            con.Open();
            login_student.ExecuteNonQuery();
            con.Close();

            int count = Convert.ToInt32(retdata.Value);

            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public List<Student> showdetails(string city)
        {
            SqlCommand show_student = new SqlCommand("proc_showdetails", con);
            show_student.Parameters.AddWithValue("@city", city);
            show_student.CommandType = CommandType.StoredProcedure;

            con.Open();

            SqlDataReader dr = show_student.ExecuteReader();

            List<Student> stulist = new List<Student>();

            while (dr.Read())
            {
                Student obj = new Student();
                obj.StudentID = dr.GetInt32(0);
                obj.StudentName = dr.GetString(1);
                obj.StudentCity = dr.GetString(2);
                obj.StudentAddress = dr.GetString(3);
                obj.StudentEmailID = dr.GetString(4);
                obj.StudentPassword = dr.GetString(5);

                stulist.Add(obj);

            }
            con.Close();

            return stulist;
        }
    
    }
}