﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_students
{
    public partial class For : Form
    {
        public For()
        {
            InitializeComponent();
        }

        private void lbl_studentname_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_add_Click(object sender, EventArgs e)
        {



        }

        private void btn_add_Click_1(object sender, EventArgs e)
        {
            if(txt_studentname.Text==String.Empty)
            {
                MessageBox.Show("enter name");
            }
            else if(txt_studentcity.Text==String.Empty)
            {
            MessageBox.Show("enter city");                  
            }
            else if(txt_studentaddress.Text==String.Empty)
            {
                MessageBox.Show("enter address");

            }
            else if(txt_studentemailid.Text==String.Empty)
            {
                MessageBox.Show("enter emailid");
            }
            if(txt_password.Text==String.Empty)
            {
                MessageBox.Show("enter password");
            }
            else
            {
                string name = txt_studentname.Text;
                string city = txt_studentcity.Text;
                string address = txt_studentaddress.Text;
                string emailid = txt_studentemailid.Text;
                string password = txt_password.Text;
                Student obj = new Student();
                obj.StudentName = name;
                obj.StudentCity = city;
                obj.StudentAddress = address;
                obj.StudentEmailID = emailid;
                obj.StudentPassword = password;

                StudentDAL dal = new StudentDAL();
                int id = dal.AddStudent(obj);
                MessageBox.Show("student added" + id);
            }
        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            if(txt_studentid.Text==String.Empty)
            {
                MessageBox.Show("enter id");
            }
            else
            {
                int id = Convert.ToInt32(txt_studentid.Text);
                StudentDAL dal = new StudentDAL();
                Student stu = dal.Find(id);
                if(stu!=null)
                {
                    txt_studentname.Text = stu.StudentName;
                    txt_studentcity.Text = stu.StudentCity;
                    txt_studentaddress.Text = stu.StudentAddress;
                    txt_studentemailid.Text = stu.StudentEmailID;

                }
                else
                {
                    MessageBox.Show("not found");
                }
            }
              

        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            if(txt_studentid.Text==String.Empty)
            {
                MessageBox.Show("enter id");

            }
            else if(txt_studentcity.Text==String.Empty)
            {
                MessageBox.Show("enter city");
            }
            else
            {
                int id = Convert.ToInt32(txt_studentid.Text);
                string city = txt_studentcity.Text;

                StudentDAL dal = new StudentDAL();
                bool status = dal.Update(id,city);
                if(status)
                {
                    MessageBox.Show("updated");
                }
                else
                {
                    MessageBox.Show("not Updated");
                }



            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if(txt_studentid.Text==String.Empty)
            {
                MessageBox.Show("enter id");
            }
            else
            {
                int id = Convert.ToInt32(txt_studentid.Text);
                StudentDAL dal = new StudentDAL();
                bool status = dal.Delete(id);
                if(status)
                {
                    MessageBox.Show("Deleted");

                }
                else
                {
                    MessageBox.Show("not deleted");
                }
            }
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            txt_studentid.Text = String.Empty;
            txt_studentname.Text = String.Empty;
            txt_studentcity.Text = String.Empty;
            txt_studentaddress.Text = String.Empty;
            txt_studentemailid.Text = String.Empty;
        }
    }
}
