﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_students
{
    public partial class frm_loginid : Form
    {
        public frm_loginid()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txt_loginid.Text);
            string password = txt_password.Text;

            StudentDAL dal = new StudentDAL();
            bool status = dal.loginid(id,password);
            if(status)
            {
                MessageBox.Show("valid user");
            }
            else
            {
                MessageBox.Show("Invalid user");
            }
        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            StudentDAL dal = new StudentDAL();
            string city = txt_studentcity.Text;
            List<Student> list = dal.showdetails(city);
            dg_student.DataSource = list;
        }
    }
}
