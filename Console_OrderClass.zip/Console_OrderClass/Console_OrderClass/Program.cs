﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OrderClass
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter customer name:");
            string custname = Console.ReadLine();

            Console.WriteLine("enter item name:");
            string itemname = Console.ReadLine();

            Console.WriteLine("enter item price:");
            int itemprice = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("enter item Quantity:");
            int itemquantity = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("enter the type of order:");
            string type = Console.ReadLine();

            Order obj = null;
            if (type == "Order")
            {

                obj = new Order(custname, itemname, itemprice, itemquantity);
            }
            else if(type=="Order_Overseas")
            {
                obj = new Order_Overseas(custname, itemname, itemprice, itemquantity);
            }

            if (obj!=null)
            {
                int amt = obj.GetOrderValue();
                Console.WriteLine(amt);
                string details = obj.GetDetails();
                Console.WriteLine(details);
            }
            Console.ReadLine();
        }
    }
}
