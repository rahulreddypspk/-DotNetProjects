﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OrderClass
{
    class Order_Overseas : Order
    {
        public Order_Overseas(string CustomerName,string ItemName,int ItemPrice,int ItemQuantity)
            :base(CustomerName,ItemName,ItemPrice,ItemQuantity)
        {

        }
        public override int  GetOrderValue()
        {
            Console.WriteLine(" after tax 10% amount is: ");

             int total = PItemPrice * PItemQuantity;
            int amt= (total / 100 * 10);
            return total - amt;
        }
        public override string GetDetails()
        {
            return POrderID + " " + PCustomerName + " " + PItemName + " " + PItemPrice + " " + PItemQuantity;
        }
    }
}
