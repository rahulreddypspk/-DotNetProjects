﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_emp_assign3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter employee id:");
            int empid = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter employee name:");
            string empname = Console.ReadLine();
            Console.WriteLine("enter employee city:");
            string empcity = Console.ReadLine();
            Console.WriteLine("enter salary:");
            double empsalary= Convert.ToDouble(Console.ReadLine());
            Employee emp = new Employee(empid, empname, empcity, empsalary);

            Console.WriteLine("enter no of days:");
            int n = Convert.ToInt32(Console.ReadLine());
            double monthsal = emp.GetEmployeeSalary(n);
            Console.WriteLine("monthly salary is: " + monthsal);
            string details = emp.GetDetails();
            Console.WriteLine(details);

            Console.ReadLine();


        }
    }
}
