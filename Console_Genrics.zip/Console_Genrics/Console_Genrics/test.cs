﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Genrics
{
    class test
    {
        public T GetDetails<T>(T para)
        {
            return para;
        }
    }
}
