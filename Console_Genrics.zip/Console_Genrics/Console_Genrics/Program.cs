﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Genrics
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> marks = new List<int>();
            marks.Add(100);
            marks.Add(200);
            int m = marks[0];

            List<string> names = new List<string>();
            names.Add("a");
            names.Add("b");

             
            foreach(int mm in marks)
            {
                Console.WriteLine(mm);
            }

            Dictionary<int, string> nameswithkeys = new Dictionary<int, string>();
            nameswithkeys.Add(1001, "ABC");
            nameswithkeys.Add(1002, "XYZ");

            string s1 = nameswithkeys[1001];

            Console.WriteLine(s1);
            test t = new test();
            int x = t.GetDetails<int>(1000);
            string str = t.GetDetails<string>("ABC");

            Console.WriteLine(x);
            Console.WriteLine(str);
            Console.ReadLine();
        }
    }
}
