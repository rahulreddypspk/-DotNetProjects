﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Employee_InterfaceConcept
{
    interface IHREMP
    {
        string GetEmployeeAddress();

        int GetEmployeeSalary();

        int GetEmployeeID();
    }
}
