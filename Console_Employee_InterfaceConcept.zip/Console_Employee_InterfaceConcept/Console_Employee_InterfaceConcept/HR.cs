﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Employee_InterfaceConcept
{
    class HR
    {
        public void GetEmployee(IHREMP obj1)
        {
            string EmpAdd = obj1.GetEmployeeAddress();
            int EmpSal = obj1.GetEmployeeSalary();
            int EmpID = obj1.GetEmployeeID();

            Console.WriteLine(EmpAdd + " " + EmpSal + " " + EmpID);
        }
    }
}
