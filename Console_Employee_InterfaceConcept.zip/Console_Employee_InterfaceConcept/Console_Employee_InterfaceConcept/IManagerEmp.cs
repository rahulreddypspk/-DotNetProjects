﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Employee_InterfaceConcept
{
    interface IManagerEmp
    {
        int GetEmployeeID();
        int GetEmployeeExp();
        string GetEmployeeProjectDetails();
    }
}
