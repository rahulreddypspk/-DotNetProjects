﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Employee_InterfaceConcept
{
    class Account
    {
        public void GetEmployee(IAccountEmp obj2)
        {
           int EmpSal= obj2.GetEmployeeSalary();
            int EmpAccNum = obj2.GetEmployeeAccountNumber();
            string EmpAdd = obj2.GetEmployeeAddress();

            Console.WriteLine(EmpSal + " " + EmpAccNum + " " + EmpAdd);


        }
    }
}
