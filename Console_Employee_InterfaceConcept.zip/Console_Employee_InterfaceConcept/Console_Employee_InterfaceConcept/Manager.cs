﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Employee_InterfaceConcept
{
    class Manager
    {
        public void GetEmployee(IManagerEmp obj3)
        {
            int EmpID = obj3.GetEmployeeID();
            int EmpExp = obj3.GetEmployeeExp();
            string EmpProjectDetails = obj3.GetEmployeeProjectDetails();

            Console.WriteLine(EmpID + " " + EmpExp + " " + EmpProjectDetails);
        }
    }
}
