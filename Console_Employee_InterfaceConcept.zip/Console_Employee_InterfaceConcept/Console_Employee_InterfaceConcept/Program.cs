﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Employee_InterfaceConcept
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee(123456, "rahul", "HYD", 20000, "LB nagar", "ONline Storee",2, 14789, "SBI", 22);

            HR h = new HR();
            Account a = new Account();
            Manager m = new Manager();

            h.GetEmployee(emp);
            a.GetEmployee(emp);
            m.GetEmployee(emp);

            Console.ReadLine();
        }
    }
}
