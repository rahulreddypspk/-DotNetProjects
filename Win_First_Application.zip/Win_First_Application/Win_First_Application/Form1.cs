﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_First_Application
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Lb1_LoginID_Load(object sender, EventArgs e)
        {

        }

       

        private void Bt_Login_Click(object sender, EventArgs e)
        {
            if(txt_login_id.Text==string.Empty)
            {
                MessageBox.Show("Enter ID:");
            }
            else
                if(txt_password.Text==string.Empty)
            {
                MessageBox.Show("Enter Password:");
            }
            else
            {
                string LoginID = txt_login_id.Text;
                string password = txt_password.Text;
                if(LoginID=="admin@gmail.com"&&password=="pass@123")
                {
                    MessageBox.Show("valid User");
                    frm_sum obj = new frm_sum();
                    obj.Show();
             
                }
                else
                {
                    MessageBox.Show("Invalid User");
                }
            }
        }
    }
}
