﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_First_Application
{
    public partial class frm_sum : Form
    {
        public frm_sum()
        {
            InitializeComponent();
        }

        private void frm_sum_Load(object sender, EventArgs e)
        {

        }
        
        private void btn_sum_Click(object sender, EventArgs e)
        {
            if(txt_num1.Text==string.Empty)
            {
                MessageBox.Show("enter Num1:");
            }
            else if(txt_num2.Text==string.Empty)
            {
                MessageBox.Show("Enter Num2:");

            }
            else
            {
                int number1 = Convert.ToInt32(txt_num1.Text);
                int number2 = Convert.ToInt32(txt_num2.Text);
                int total = number1 + number2;
                MessageBox.Show("Total :" + total);
            }
        }
    }
}
