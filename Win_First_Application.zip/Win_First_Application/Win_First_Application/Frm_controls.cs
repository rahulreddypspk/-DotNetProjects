﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_First_Application
{
    public partial class Frm_controls : Form
    {
        public Frm_controls()
        {
            InitializeComponent();
        }

        private void lst_cities_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            if (rdb_male.Checked == false && rdb_female.Checked == false)
            {
                MessageBox.Show("Slect Your Gender");
            }
            else
            {
                string gender = string.Empty;
                if (rdb_male.Checked)
                {
                    gender = "Male";
                }
                else if (rdb_female.Checked)
                {
                    gender = "Female";
                }
                MessageBox.Show(gender);

                bool status = chk_readme.Checked;

                if (status)
                {
                    MessageBox.Show("It is Checked");
                }
                else
                {
                    MessageBox.Show("Not Checked");
                }

                if (lst_cities.Text == string.Empty)
                {
                    MessageBox.Show("select a city");
                }
                else
                {
                    string city = lst_cities.Text;
                    MessageBox.Show(city);
                }
            }
        }

        private void Frm_controls_Load(object sender, EventArgs e)
        {
            lst_cities.Items.Add("Pune");
            lst_cities.Items.Add("Chennai");
            lst_cities.Items.Add("HYD");

            cmb_cities.Items.Add("Pune");
            cmb_cities.Items.Add("Chennai");
            cmb_cities.Items.Add("HYD");


        }

        private void cmb_cities_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
