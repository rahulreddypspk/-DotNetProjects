﻿namespace Win_First_Application
{
    partial class Frm_controls
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lst_cities = new System.Windows.Forms.ListBox();
            this.btn_save = new System.Windows.Forms.Button();
            this.cmb_cities = new System.Windows.Forms.ComboBox();
            this.chk_readme = new System.Windows.Forms.CheckBox();
            this.rdb_male = new System.Windows.Forms.RadioButton();
            this.rdb_female = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // lst_cities
            // 
            this.lst_cities.FormattingEnabled = true;
            this.lst_cities.ItemHeight = 16;
            this.lst_cities.Location = new System.Drawing.Point(45, 85);
            this.lst_cities.Name = "lst_cities";
            this.lst_cities.Size = new System.Drawing.Size(186, 164);
            this.lst_cities.TabIndex = 0;
            this.lst_cities.SelectedIndexChanged += new System.EventHandler(this.lst_cities_SelectedIndexChanged);
            // 
            // btn_save
            // 
            this.btn_save.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_save.Location = new System.Drawing.Point(298, 92);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(102, 46);
            this.btn_save.TabIndex = 1;
            this.btn_save.Text = "save";
            this.btn_save.UseVisualStyleBackColor = true;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // cmb_cities
            // 
            this.cmb_cities.FormattingEnabled = true;
            this.cmb_cities.Location = new System.Drawing.Point(86, 310);
            this.cmb_cities.Name = "cmb_cities";
            this.cmb_cities.Size = new System.Drawing.Size(121, 24);
            this.cmb_cities.TabIndex = 2;
            this.cmb_cities.SelectedIndexChanged += new System.EventHandler(this.cmb_cities_SelectedIndexChanged);
            // 
            // chk_readme
            // 
            this.chk_readme.AutoSize = true;
            this.chk_readme.Location = new System.Drawing.Point(297, 188);
            this.chk_readme.Name = "chk_readme";
            this.chk_readme.Size = new System.Drawing.Size(87, 21);
            this.chk_readme.TabIndex = 3;
            this.chk_readme.Text = "Read Me";
            this.chk_readme.UseVisualStyleBackColor = true;
            // 
            // rdb_male
            // 
            this.rdb_male.AutoSize = true;
            this.rdb_male.Location = new System.Drawing.Point(290, 254);
            this.rdb_male.Name = "rdb_male";
            this.rdb_male.Size = new System.Drawing.Size(59, 21);
            this.rdb_male.TabIndex = 4;
            this.rdb_male.TabStop = true;
            this.rdb_male.Text = "Male";
            this.rdb_male.UseVisualStyleBackColor = true;
            // 
            // rdb_female
            // 
            this.rdb_female.AutoSize = true;
            this.rdb_female.Location = new System.Drawing.Point(422, 255);
            this.rdb_female.Name = "rdb_female";
            this.rdb_female.Size = new System.Drawing.Size(75, 21);
            this.rdb_female.TabIndex = 5;
            this.rdb_female.TabStop = true;
            this.rdb_female.Text = "Female";
            this.rdb_female.UseVisualStyleBackColor = true;
            // 
            // Frm_controls
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(867, 427);
            this.Controls.Add(this.rdb_female);
            this.Controls.Add(this.rdb_male);
            this.Controls.Add(this.chk_readme);
            this.Controls.Add(this.cmb_cities);
            this.Controls.Add(this.btn_save);
            this.Controls.Add(this.lst_cities);
            this.Name = "Frm_controls";
            this.Text = "Frm_controls";
            this.Load += new System.EventHandler(this.Frm_controls_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lst_cities;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.ComboBox cmb_cities;
        private System.Windows.Forms.CheckBox chk_readme;
        private System.Windows.Forms.RadioButton rdb_male;
        private System.Windows.Forms.RadioButton rdb_female;
    }
}