﻿namespace Wind_Threads
{
    partial class frm_locking1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Number1 = new System.Windows.Forms.Label();
            this.lbl_Number2 = new System.Windows.Forms.Label();
            this.txt_Number1 = new System.Windows.Forms.TextBox();
            this.txt_Number2 = new System.Windows.Forms.TextBox();
            this.btn_Thread1 = new System.Windows.Forms.Button();
            this.btn_Thread2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_Number1
            // 
            this.lbl_Number1.AutoSize = true;
            this.lbl_Number1.Location = new System.Drawing.Point(68, 75);
            this.lbl_Number1.Name = "lbl_Number1";
            this.lbl_Number1.Size = new System.Drawing.Size(70, 17);
            this.lbl_Number1.TabIndex = 0;
            this.lbl_Number1.Text = "Number 1";
            // 
            // lbl_Number2
            // 
            this.lbl_Number2.AutoSize = true;
            this.lbl_Number2.Location = new System.Drawing.Point(60, 157);
            this.lbl_Number2.Name = "lbl_Number2";
            this.lbl_Number2.Size = new System.Drawing.Size(70, 17);
            this.lbl_Number2.TabIndex = 1;
            this.lbl_Number2.Text = "Number 2";
            // 
            // txt_Number1
            // 
            this.txt_Number1.Location = new System.Drawing.Point(223, 69);
            this.txt_Number1.Name = "txt_Number1";
            this.txt_Number1.Size = new System.Drawing.Size(100, 22);
            this.txt_Number1.TabIndex = 2;
            // 
            // txt_Number2
            // 
            this.txt_Number2.Location = new System.Drawing.Point(222, 162);
            this.txt_Number2.Name = "txt_Number2";
            this.txt_Number2.Size = new System.Drawing.Size(100, 22);
            this.txt_Number2.TabIndex = 3;
            // 
            // btn_Thread1
            // 
            this.btn_Thread1.Location = new System.Drawing.Point(131, 267);
            this.btn_Thread1.Name = "btn_Thread1";
            this.btn_Thread1.Size = new System.Drawing.Size(75, 23);
            this.btn_Thread1.TabIndex = 4;
            this.btn_Thread1.Text = "Thread1";
            this.btn_Thread1.UseVisualStyleBackColor = true;
            this.btn_Thread1.Click += new System.EventHandler(this.btn_Thread1_Click);
            // 
            // btn_Thread2
            // 
            this.btn_Thread2.Location = new System.Drawing.Point(321, 260);
            this.btn_Thread2.Name = "btn_Thread2";
            this.btn_Thread2.Size = new System.Drawing.Size(75, 23);
            this.btn_Thread2.TabIndex = 5;
            this.btn_Thread2.Text = "Thread2";
            this.btn_Thread2.UseVisualStyleBackColor = true;
            this.btn_Thread2.Click += new System.EventHandler(this.btn_Thread2_Click);
            // 
            // frm_locking1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(627, 415);
            this.Controls.Add(this.btn_Thread2);
            this.Controls.Add(this.btn_Thread1);
            this.Controls.Add(this.txt_Number2);
            this.Controls.Add(this.txt_Number1);
            this.Controls.Add(this.lbl_Number2);
            this.Controls.Add(this.lbl_Number1);
            this.Name = "frm_locking1";
            this.Text = "frm_locking1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Number1;
        private System.Windows.Forms.Label lbl_Number2;
        private System.Windows.Forms.TextBox txt_Number1;
        private System.Windows.Forms.TextBox txt_Number2;
        private System.Windows.Forms.Button btn_Thread1;
        private System.Windows.Forms.Button btn_Thread2;
    }
}