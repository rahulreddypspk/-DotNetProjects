﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_calc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void lbl_sum_Click(object sender, EventArgs e)
        {

        }

        private void btn_result_Click(object sender, EventArgs e)
        {

            
        }

        private void btn_sum_Click(object sender, EventArgs e)
        {
            if (txt_number1.Text == string.Empty)
            {
                MessageBox.Show("Enter number 1:");
            }
            else if (txt_number2.Text == string.Empty)
            {
                MessageBox.Show("Enter number 2:");
            }
            else
            {
                int num1 = Convert.ToInt32(txt_number1.Text);
                int num2 = Convert.ToInt32(txt_number2.Text);

                Calculator.Cal obj = new Calculator.Cal();
                int sum = obj.GetSum(num1, num2);
                lbl_sum.Text = sum.ToString();
            }
        }

        private void btn_divide_Click(object sender, EventArgs e)
        {

        }

        private void btn_multiply_Click(object sender, EventArgs e)
        {
            if (txt_number1.Text == string.Empty)
            {
                MessageBox.Show("Enter number 1:");
            }
            else if (txt_number2.Text == string.Empty)
            {
                MessageBox.Show("Enter number 2:");
            }
            else
            {
                int num1 = Convert.ToInt32(txt_number1.Text);
                int num2 = Convert.ToInt32(txt_number2.Text);

                Calculator.Cal obj = new Calculator.Cal();
                int mul = obj.GetMultiply(num1, num2);
                lbl_multiply.Text = mul.ToString();
            }
        }

        private void btn_divide_Click_1(object sender, EventArgs e)
        {
            if (txt_number1.Text == string.Empty)
            {
                MessageBox.Show("Enter number 1:");
            }
            else if (txt_number2.Text == string.Empty)
            {
                MessageBox.Show("Enter number 2:");
            }
            else
            {
                int num1 = Convert.ToInt32(txt_number1.Text);
                int num2 = Convert.ToInt32(txt_number2.Text);

                Calculator.Cal obj = new Calculator.Cal();
                int div = obj.GetDivide(num1, num2);
                lbl_divide.Text = div.ToString();
            }
        }

        private void btn_subtract_Click(object sender, EventArgs e)
        {
            if (txt_number1.Text == string.Empty)
            {
                MessageBox.Show("Enter number 1:");
            }
            else if (txt_number2.Text == string.Empty)
            {
                MessageBox.Show("Enter number 2:");
            }
            else
            {
                int num1 = Convert.ToInt32(txt_number1.Text);
                int num2 = Convert.ToInt32(txt_number2.Text);

                Calculator.Cal obj = new Calculator.Cal();
                int sub = obj.GetSubtract(num1, num2);
                lbl_subtract.Text = sub.ToString();
            }
        }

        private void txt_number2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}