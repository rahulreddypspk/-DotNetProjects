﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_orderId_hw
{
    class order
    {
        private int OrderID;
        private string CustomerName;
       private string ItemName;
       private int ItemPrice;
            private int ItemQuantity;


            public int POrderID
        {
            get
            {
                return this.POrderID;
            }
        }
        public string PCustomerName
        {
            get
            {
                return this.CustomerName;
            }
        }
        public string PItemName
        {
            get
            {
                return this.ItemName;
            }
            set
            {
                return this.ItemName;
            }
        }
        public int PItemPrice
        {
            get
            {
                return this.ItemPrice;
            }
        }
        public int PItemQuantity
        {
            get
            {
                return this.ItemQuantity;

            }
            set
            {
                if(value<0)
                {
                     this.ItemQuantity=0;
                }
                else
                {
                   this.ItemQuantity = value;
                }
                        }
        }
        private static int count = 100;
        public order(string CustomerName,string ItemName,int ItemPrice,int ItemQuantity)
        {
            order.count++;
            this.OrderID = order.count;
            this.CustomerName = CustomerName;
            this.ItemName = ItemName;
            this.ItemPrice = ItemPrice;
            this.ItemQuantity = ItemQuantity;

        }
        public int GetOrderAmount()
        {
            return ItemPrice * ItemQuantity;
        }
        public string GetDetails()
        {
            return OrderID + " " + CustomerName + " " + ItemName + " " + ItemPrice + " " + ItemQuantity;
        }
    }
}
