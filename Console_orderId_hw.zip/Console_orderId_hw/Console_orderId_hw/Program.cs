﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_orderId_hw
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter customer name:");
            string custname = Console.ReadLine();
            Console.WriteLine("enter item name");
            string itemname = Console.ReadLine();
            Console.WriteLine("enter item Price:");
            int itemprice = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter the item quantity");
            int itemqty = Convert.ToInt32(Console.ReadLine());

            order obj = new order(custname, itemname, itemprice, itemqty);
            int amt = obj.GetOrderAmount();
            Console.WriteLine("amount to be paid is:" + amt);
          
            obj.PItemname = biscuit;
            Console.WriteLine(obj.PItemName);
            string details = obj.GetDetails();
            Console.WriteLine(details);
            Console.ReadLine();
        }
    }
}
 