﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test
{
    public class Class1
    {
        public string call1()
        {
            return "Hello from call1";
        }

        public string call2()
        {
            return "hello from call2";
        }
    }
}
