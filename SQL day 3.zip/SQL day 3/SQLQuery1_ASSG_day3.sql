 
 select * from tbl_Customer

 --1
 create proc p_Customer( @id int,@name varchar(100),@city varchar(100),@salary int)
 as
 insert tbl_Customer values(@id,@name,@city,@salary)
 
 declare @c int
 exec @c=p_Customer 2001,'rahul','HYD',20000

 --2
 alter proc U_Customer(@id int,@name varchar(100),@city varchar(100))
 as
 update tbl_Customer set CustomerName=@name,CustomerCity=@city where CustomerID=@id

 declare @u int
 exec @u=U_Customer 1001,'reddy','GOA'

 --3
 select * from Customerinfo
 alter proc M_CustomerINFO(@MoblieNO varchar(20),@ID int,@Password int) 
 as
 update Customerinfo set customerMoblieNO=@MoblieNO where CustomerID=@id and CustomerPassword=@Password
 return 1

 declare @m int
 exec @m=M_CustomerINFO '8686405407',101,0000
 select @m

 --4

create proc CA_CAinfo(@id int)
as
select c.CustomerID,c.CustomerName,a.AccountID,a.AccountBalance from Customerinfo c join Accountinfo a
on c.CustomerID=a.CustomerID
return 1

declare @ca int
exec CA_CAinfo 101
select @ca

--5
select * from Accountinfo
select * from Customerinfo
 
 alter trigger Updating_AB
 on TransactionINFO
 for insert
 as
 begin
 declare @Ttype varchar(100)
 declare @amt int 
 declare @AccID int
 select @AccID=AccountID ,@amt=Amount,@Ttype=transactiontype from inserted 
 if(@Ttype='debit')
 begin 
 update Accountinfo set AccountBalance=AccountBalance-@amt where AccountID=@AccID
 end
 if(@Ttype='credit')
 begin 
 update Accountinfo set AccountBalance=AccountBalance+@amt where AccountID=@AccID
 end
 end

 insert TransactionInfo values(1001,'debit',10000,Getdate())

 --6
 create view V_table
 as
 select c.customerID,c.Customername,a.AccountID,a.AccountBalance from 
 Customerinfo c join Accountinfo a on
 c.CustomerID=a.CustomerID

 select * from V_table

 --7
 select * from Customerinfo

 alter proc p_table(@id int,@password varchar(100))
 as
 declare @count int
 select @count=count(*) from Customerinfo where CustomerID=@id and CustomerPassword=@password
 if(@count=1)
 begin
 return 1
 end
 else
 begin
 return 0
 end

 declare @m int
 exec @m=p_table 102,'1111'
 select @m

 sp_help CustomerINFO