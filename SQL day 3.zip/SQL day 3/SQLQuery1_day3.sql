declare @count int=0;

set @count=100;

select @count=count(*) from tbl_Employees
select @count;

if(@count=0)
begin
--insert
end
else
begin
--update
end
select @count;



declare @count int=0;
while(@count<10)
begin
Select @count;
set @count=@count+1;
end


--create procedure
alter proc sp_Employees
as
select * from tbl_Employees order  by EmployeeSalary desc

exec sp_Employees


create proc sp_Employee_city(@city varchar(100))
as
select * from tbl_Employees where EmployeeCity=@city

exec Sp_Employee_city 'chennai'

select * from tbl_Accounts

create proc sp_add_account(@name varchar(100),@balance int)
as
if(@balance>=1000)
begin
insert tbl_accounts values(@name,@balance)
return @@identity
end
else
begin 
return 0
end

declare @r int
exec @r=sp_Add_account 'abcd',20000
select @r


create proc sp_Account_balance(@accountID int)
as
declare @balance int
select @balance=Accountbalance from tbl_accounts where AccountID=@accountID
return @balance

declare @bal int
exec @bal=sp_Account_balance 1000
select @bal




select * from Customerinfo


create proc sp_login(@id int ,@password varchar(100))
as
declare @count int
select @count=count(*) from Customerinfo
where CustomerID=@id and CustomerPassword=@password
return @count

declare @c int
exec @c=sp_login 101,'0000'
select @c


select * from tbl_Employees

create proc sp_employeedetails(@id int,@name varchar(100) output,@city varchar(100) output)
as
select @name=EmployeeName,@city=EmployeeCity from tbl_Employees where EmployeeID=@id

declare @ename varchar(100)
declare @ecity varchar(100)
exec sp_Employeedetails  1001,@ename output,@ecity output
select @ename,@ecity



create table tbl_Students
(
StudentID int,
StudentName varchar(100),
StudentCity varchar (100)
)
alter Trigger trg_add_student
on tbl_Students
for insert
as
begin
select * from inserted
select 'trigger fired'
end

insert tbl_students values(3,'a','HYD')


select * from tbl_students


create table tbl_stocks
(
ItemId int identity(1,1) primary key,
ItemQty int not null
)

insert tbl_stocks values(200)

create table Orders
(
OrderID int identity(1001,1),
ItemID int not null foreign key references tbl_Stocks(ItemID),
OrderQty int not null,
OrderPrice int not null
)


insert Orders values(5,20,400)

select * from Orders

select * from tbl_stocks

alter trigger trg_update_stock
on orders
for insert
as
begin
declare @itemID int
declare @qty int
select @itemID=itemID,@qty=OrderQty from inserted 
update tbl_stocks set ItemQty=ItemQty-@qty where itemID=@itemID
end




select * from tbl_Employees

alter view v_Employees_HYD
with encryption,schemabinding
as
select EmployeeID,EmployeeName,EmployeeSalary,EmployeeCity from dbo.tbl_Employees where EmployeeCity='HYD'
with check option

drop table tbl_Employees

select * from v_Employees_HYD
insert v_Employees_HYD values(1005,'abc','mumbai',3000)


sp_helptext V_Employees_hyd




create table t1
(
code int,
name varchar(100)
)

insert t1 values(1,'a')
create table t2
(
code int ,
city varchar(100)
)

insert t2 values(1,'bgl')
select * from t1
select * from t2

create view v_data
as
select t1.code,t1.name,t2.city from t1 join t2 on t1.code=t2.code

select * from v_data

insert v_data values(2,'xyz','pune')

create trigger trg_view
on v_data
instead of insert
as
begin
declare @code int
declare @name varchar(100)
declare @city varchar(100)
select @code=code,@name=name,@city=city from inserted
insert t1 values (@code,@name)
insert t2 values(@code,@city)
end



create table tbl_Employeeinfo
(
EmployeeID int identity(1,1),
EmployeeName varchar(100),
EmployeeCity varchar(100)
)

declare @c int=0;
while(@c<50000)
begin
insert tbl_Employeeinfo values('ABCD','HYD')
set @c=@c+1;
end

select * from tbl_Employeeinfo where EmployeeID=49999


create Clustered index idx
on tbl_EmployeeINFO(EmployeeID)


select * from tbl_Employees

begin tran tr1

insert tbl_Employees values(1010,'abc','bgl',20000)

select * from tbl_Employees

rollback tran

commit tran
