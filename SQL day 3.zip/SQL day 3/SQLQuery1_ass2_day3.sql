 create database EmployeesManagementDB

 use EmployeesManagementDB

 create table tbl_employees
 (
 EmployeeID int not null primary key,
 EmployeeName varchar(100) not null,
 EmployeeCity varchar(100) not null,
 EmployeeSalary int not null,
 EmployeeDOB datetime not null,
 EmployeeDOJ datetime not null,
 EmployeeMobileNO varchar(100) not null,
 EmployeeEmailID varchar(100) not null,
 EmployeePassword varchar(100) not null,
 EmployeeDEPT varchar(100) not null
 )

 insert tbl_Employees values(1001,'rahul','HYD',20000,'25-11-1996','12-12-2018','7702409796',
 'rahul1@gmail.com','0000','IT')

 create table tbl_Employee_available_leaves
 (
 EmployeeID int not null foreign key references tbl_Employees(EmployeeID),
 sickLeave varchar(100) not null,
 casualLeave varchar(100) not null,
 VacationLeave varchar(100) not null,
 ComOFF varchar(100) NOT NULL
 )

 create table tbl_EmployeeLeaves
 (
 EmployeeId int not null foreign key References tbl_Employees(employeeID),
 LeaveType varchar(100) not null,
 LeaveApplyDate datetime not null,
 LeaveDate datetime not null,
 NOOFLeaves int not null
 )

 create table tbl_EmployeeSalary
 (
 EmployeeID int not null foreign key references tbl_Employees(EmployeeID),
 EmployeeSalary int not null,
 SalaryMonth varchar(100) not null,
 SalaryYear varchar not null,
 SalaryDate datetime not null
 )