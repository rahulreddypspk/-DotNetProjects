select * from tbl_employees


--1
create proc proc_addemployee(@name varchar(100),@city varchar(100),@password varchar(100))
as
insert tbl_employees values(@name,@city,@password,getdate())
return @@identity

--2
create proc proc_employeedetails(@id int)
as
select * from tbl_employees where EmployeeID=@id

--3
create proc proc_showemployees(@city varchar(100))
as
select * from tbl_employees where EmployeeCity=@city

--4
create proc proc_searchemployee(@key varchar(100))
as
select * from tbl_employees where EmployeeID like '%'+@key+'%' or EmployeeName like '%'+@key+'%' or EmployeeCity like '%'+@key+'%';

--5
create proc proc_updateemployee(@id int,@city varchar(100),@password varchar(100))
as
update tbl_employees set EmployeeCity=@city , EmployeePassword=@password where EmployeeID=@id
return @@rowcount

--6
create proc proc_deleteemployee(@id int)
as
delete tbl_employees where EmployeeID=@id
return @@rowcount

--7
create proc proc_login(@id int,@password varchar(100))
as
declare @count int
select @count=count(*) from tbl_employees where EmployeeID=@id and EmployeePassword=@password
return @count






select * from Customers


--1
create proc add_customer(@name varchar(100),@password varchar(100),@city varchar(100),@address varchar(100),@mobileno varchar(100),@emailid varchar(100))
as
insert Customers values( @name,@password,@city,@address,@mobileno,@emailid)
return @@identity


--2
create proc find_customer(@id int)
as
select * from Customers where CustomersID=@id


--3
create proc update_customer(@password varchar(100),@city varchar(100),@id int)
as
update Customers set CustomerPassword=@password,CustomerCity=@city where CustomersID=@id
return @@rowcount


--4
create proc delete_customer(@id int)
as
delete Customers where CustomersID=@id
return @@rowcount

--5
create proc show_customercity(@city varchar(100))
as
select * from Customers where CustomerCity=@city



--6
create proc login_customer(@id int,@password varchar(100))
as
declare @count int
select @count=count(*) from Customers where CustomersID=@id and CustomerPassword=@password
return @count


--8
create proc show_customer(@city varchar(100))
as
select * from Customers where CustomerCity=@city