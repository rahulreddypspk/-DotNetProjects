﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Dictionar_ForEach
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, string> names = new Dictionary<string, string>();
            names.Add("e1", "Ajay");
            names.Add("e2", "Vijay");
            names.Add("e3", "John");
            names.Add("e4", "Rosy");

            foreach(KeyValuePair<string,string> s in names)
            {
                Console.WriteLine(s.Key + " " + s.Value);
            }

            foreach(string k in names.Keys)
            {
                Console.WriteLine(k);
            }

            foreach(string v in names.Values)
            {
                Console.WriteLine(v);
            }

            string name = names["e1"];
            Console.WriteLine(name);

            Console.ReadLine();
        }
    }
}
