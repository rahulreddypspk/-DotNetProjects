﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Console_Collections
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList list = new ArrayList();
            list.Add(1000);
            list.Add(2000);
            list.Add(3000);
            int x = 4000;
            list.Add(x);
            list.Add("abc");

            int x1 = Convert.ToInt32(list[0]);
            string s1 = list[4].ToString();
            Console.WriteLine(x1);
            Console.WriteLine(s1);
           /* foreach(int m in list)
            {
                Console.WriteLine(m);
            }*/
            Console.WriteLine(list.Count);
            list.Remove(1000);
            list.RemoveAt(0);

            


            Console.ReadLine();
        }
    }
}
