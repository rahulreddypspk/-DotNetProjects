﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Console_MUTEX_semaphore
{
    class Program
    {
        static void Main(string[] args)
        {
            bool status;
            // Mutex m = new Mutex(false, "xyz", out status);
            //Console.WriteLine(status);

            Semaphore sm = new Semaphore(2, 2);
            Task t1 = Task.Run(() =>
              {
                  //     m.WaitOne();
                  sm.WaitOne();
                  Console.WriteLine("task 1 started");
                  Thread.Sleep(10000);
                  Console.WriteLine("task 1 Completed");
                  //   m.ReleaseMutex();
                  sm.Release();
              });


            Task t2 = Task.Run(() =>
            {
                sm.WaitOne();
                //m.WaitOne();
                Console.WriteLine("task 2 started");
                Thread.Sleep(10000);
                Console.WriteLine("task 2 Completed");

                //m.ReleaseMutex();
                sm.Release();
            });


            Task t3= Task.Run(() =>
            {
                sm.WaitOne();
                //m.WaitOne();
                Console.WriteLine("task 3 started");
                Thread.Sleep(10000);
                Console.WriteLine("task 3 Completed");

                //m.ReleaseMutex();
                sm.Release();
            });

            Console.ReadLine();
        }
    }
}
