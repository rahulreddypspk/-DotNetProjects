﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Console_linq_xml
{
    class Program
    {
        static void Main(string[] args)
        {

            XElement orders = new XElement("Orders",

                new XElement("Order",
                                    new XElement("OrerID", "1001"),
                                    new XElement("CustomerName", "XYZ"),
                                    new XElement("Orderamt", "2000")),

                new XElement("Order",
                                    new XElement("OrderID", "1002"),
                                    new XElement("CustomerName", "Rahul"),
                                    new XElement("Orderamt", "3000"))
         );

            orders.Save(@"c:/xml/orders.xml");
            Console.WriteLine("Xml file Created");

            /* string url = @"F:\dot net\Console_linq_xml\Console_linq_xml\XMLFile1.xml";

             XDocument doc = XDocument.Load(url);

             var data = from x in doc.Descendants("Customer")
                        //where x.Element("CustomerCity").Value="BGL"
                        select new
                        {
                            CID = x.Element("CustomerID").Value,
                            CName = x.Element("CustomerName").Value,
                            CCity = x.Element("CustomerCity").Value

                        };

             foreach(var d in data)
             {
                 Console.WriteLine(d.CID + " " + d.CName + " " + d.CCity);
             }
             */
            Console.ReadLine();
        }
    }
}
