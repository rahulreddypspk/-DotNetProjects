﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace console_Delegates
{
    class Program
    {
        static void Main(string[] args)
        {
            Test obj = new Test();

            int x = 100;

            Test.del d = new Test.del(obj.call1);

            d += new Test.del(obj.call2);

            d -= new Test.del(obj.call1);

            d += new Test.del(obj.call1);

            d += delegate (string s)
             {
                 Console.WriteLine("Anonymous function :" + s +" " + x);
             };

           d += (s) => Console.WriteLine(s);//Lamda Expression

            d("hello Delegate");
            Console.ReadLine();

        }
    }
}
