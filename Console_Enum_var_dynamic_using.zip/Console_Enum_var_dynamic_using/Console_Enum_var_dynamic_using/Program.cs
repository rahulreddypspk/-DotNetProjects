﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Console_Enum_var_dynamic_using1;
using Console_Enum_var_dynamic_using1.test;

namespace Console_Enum_var_dynamic_using
{
    class Program
    {
        static void Main(string[] args)
        {
            var i = 100;
            x.test t = new x.test();
            t.MakePayment(PaymentType.NetBanking);
            call();    }
    }
}
