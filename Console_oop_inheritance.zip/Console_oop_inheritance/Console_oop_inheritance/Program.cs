﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop_inheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter customer emailID:");
            string Email = Console.ReadLine();
            Console.WriteLine("enter customer name:");
            string Name = Console.ReadLine();

            Console.WriteLine("enter customer type:");
            string type = Console.ReadLine();
            if (type == "Online")
            {
                Console.WriteLine("enter paymenttype:");
                string PaymentType = Console.ReadLine();
                Console.WriteLine("enter address:");
                string DeliveryAddress = Console.ReadLine();
                customer_online obj_online = new customer_online(Email, Name, PaymentType, DeliveryAddress);
                Console.WriteLine(obj_online.PCustomerEmailID + " " + obj_online.PCustomerName + " " + obj_online.PPaymentType + " " + obj_online.PDeliveryAddress);
            }
            else
            {
                customer obj = new customer(Email, Name);
                Console.WriteLine(obj.PCustomerEmailID + " " + obj.PCustomerName);
            }
            Console.ReadLine();
        }
    }
}
