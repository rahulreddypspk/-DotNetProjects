﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop_inheritance
{
    class customer
    {
        private string CustomerEmailID;
        private string CustomerName;

        public customer(string CustomerEmailID,string CustomerName)
        {
            this.CustomerEmailID = CustomerEmailID;
            this.CustomerName = CustomerName;
            Console.WriteLine("customer constructor");

        }
        public string PCustomerEmailID
        {
            get
            {
                return CustomerEmailID;
            }
        }
        public string PCustomerName
        {
            get
            {
                return CustomerName;
            }
        }
    }
}
