﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop_inheritance
{
    class customer_online : customer
    {
        private string PaymentType;
        private string DeliveryAddress;

        public customer_online(string CustomerEmailID,string CustomerName,string PaymentType,string DeliveryAddress) :base(CustomerEmailID,CustomerName)
        {
            this.PaymentType = PaymentType;
            this.DeliveryAddress = DeliveryAddress;
            Console.WriteLine("customer online constructor");

        }
        public string PPaymentType
        {
            get
            {
                return this.PaymentType;
            }
        }
        public string PDeliveryAddress
        {
            get
            {
                return this.DeliveryAddress;
            }
        }
    }
}
